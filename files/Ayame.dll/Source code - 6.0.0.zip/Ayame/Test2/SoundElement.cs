﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace Test2
{
	public	struct	ProjectSettings
	{
		public	Size			windowSize;
		public	Point			windowLocation;

		public	Point			ctrlLocation;
		public	int				masterVolume;
		public	bool			mute;
		public	string			soundDeviceGuid;

		public	SoundElement[]	element;
	}

	public	struct	SoundElement
	{
		public	Point	windowLocation;
		public	int		groupNo;
		public	string	name;
		public	string	filePath;
		public	string	filePathRel;
		public	int		shortCutKey;
		public	int		volume;
		public	int		pan;
		public	float	fadeinTime;
		public	float	fadeoutTime;
		public	float	pitch;
		public	bool	loop;
		public	bool	minMode;
	}
}
