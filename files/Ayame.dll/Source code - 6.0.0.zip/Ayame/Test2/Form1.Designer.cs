﻿namespace Test2
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ファイルFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Load_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Save_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RenameSave_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Quit_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Add_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.操作RToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AllStop_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ヘルプHToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Version_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.DeviceSel_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ファイルFToolStripMenuItem,
            this.Add_ToolStripMenuItem,
            this.操作RToolStripMenuItem,
            this.ヘルプHToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(841, 26);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ファイルFToolStripMenuItem
            // 
            this.ファイルFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Load_ToolStripMenuItem,
            this.Save_ToolStripMenuItem,
            this.RenameSave_ToolStripMenuItem,
            this.Quit_ToolStripMenuItem});
            this.ファイルFToolStripMenuItem.Name = "ファイルFToolStripMenuItem";
            this.ファイルFToolStripMenuItem.Size = new System.Drawing.Size(85, 22);
            this.ファイルFToolStripMenuItem.Text = "ファイル(&F)";
            // 
            // Load_ToolStripMenuItem
            // 
            this.Load_ToolStripMenuItem.Name = "Load_ToolStripMenuItem";
            this.Load_ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.Load_ToolStripMenuItem.Size = new System.Drawing.Size(274, 22);
            this.Load_ToolStripMenuItem.Text = "開く(&L)";
            this.Load_ToolStripMenuItem.Click += new System.EventHandler(this.Load_ToolStripMenuItem_Click);
            // 
            // Save_ToolStripMenuItem
            // 
            this.Save_ToolStripMenuItem.Name = "Save_ToolStripMenuItem";
            this.Save_ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.Save_ToolStripMenuItem.Size = new System.Drawing.Size(274, 22);
            this.Save_ToolStripMenuItem.Text = "保存(&S)";
            this.Save_ToolStripMenuItem.Click += new System.EventHandler(this.Save_ToolStripMenuItem_Click);
            // 
            // RenameSave_ToolStripMenuItem
            // 
            this.RenameSave_ToolStripMenuItem.Name = "RenameSave_ToolStripMenuItem";
            this.RenameSave_ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
                        | System.Windows.Forms.Keys.S)));
            this.RenameSave_ToolStripMenuItem.Size = new System.Drawing.Size(274, 22);
            this.RenameSave_ToolStripMenuItem.Text = "名前を付けて保存(&A)";
            this.RenameSave_ToolStripMenuItem.Click += new System.EventHandler(this.RenameSave_ToolStripMenuItem_Click);
            // 
            // Quit_ToolStripMenuItem
            // 
            this.Quit_ToolStripMenuItem.Name = "Quit_ToolStripMenuItem";
            this.Quit_ToolStripMenuItem.Size = new System.Drawing.Size(274, 22);
            this.Quit_ToolStripMenuItem.Text = "終了(&Q)";
            this.Quit_ToolStripMenuItem.Click += new System.EventHandler(this.Quit_ToolStripMenuItem_Click);
            // 
            // Add_ToolStripMenuItem
            // 
            this.Add_ToolStripMenuItem.Name = "Add_ToolStripMenuItem";
            this.Add_ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.Add_ToolStripMenuItem.Size = new System.Drawing.Size(62, 22);
            this.Add_ToolStripMenuItem.Text = "追加(A&)";
            this.Add_ToolStripMenuItem.Click += new System.EventHandler(this.Add_ToolStripMenuItem_Click);
            // 
            // 操作RToolStripMenuItem
            // 
            this.操作RToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AllStop_ToolStripMenuItem,
            this.DeviceSel_ToolStripMenuItem});
            this.操作RToolStripMenuItem.Name = "操作RToolStripMenuItem";
            this.操作RToolStripMenuItem.Size = new System.Drawing.Size(62, 22);
            this.操作RToolStripMenuItem.Text = "操作(&R)";
            // 
            // AllStop_ToolStripMenuItem
            // 
            this.AllStop_ToolStripMenuItem.Name = "AllStop_ToolStripMenuItem";
            this.AllStop_ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.AllStop_ToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.AllStop_ToolStripMenuItem.Text = "全停止(&M)";
            this.AllStop_ToolStripMenuItem.Click += new System.EventHandler(this.AllStop_ToolStripMenuItem_Click);
            // 
            // ヘルプHToolStripMenuItem
            // 
            this.ヘルプHToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Version_ToolStripMenuItem});
            this.ヘルプHToolStripMenuItem.Name = "ヘルプHToolStripMenuItem";
            this.ヘルプHToolStripMenuItem.Size = new System.Drawing.Size(75, 22);
            this.ヘルプHToolStripMenuItem.Text = "ヘルプ(&H)";
            // 
            // Version_ToolStripMenuItem
            // 
            this.Version_ToolStripMenuItem.Name = "Version_ToolStripMenuItem";
            this.Version_ToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.Version_ToolStripMenuItem.Text = "バージョン情報(&V)";
            this.Version_ToolStripMenuItem.Click += new System.EventHandler(this.Version_ToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 496);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(841, 23);
            this.statusStrip1.TabIndex = 9;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(77, 18);
            this.toolStripStatusLabel1.Text = "DLL Version";
            // 
            // DeviceSel_ToolStripMenuItem
            // 
            this.DeviceSel_ToolStripMenuItem.Name = "DeviceSel_ToolStripMenuItem";
            this.DeviceSel_ToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.DeviceSel_ToolStripMenuItem.Text = "デバイス出力(&D)";
            this.DeviceSel_ToolStripMenuItem.Click += new System.EventHandler(this.DeviceSel_ToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 519);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "効果音ポンだしくん";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.Form1_DragDrop);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.Form1_DragEnter);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem ファイルFToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem Load_ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem Save_ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem Quit_ToolStripMenuItem;
		private System.Windows.Forms.StatusStrip statusStrip1;
		private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
		private System.Windows.Forms.ToolStripMenuItem Add_ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 操作RToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem AllStop_ToolStripMenuItem;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;
		private System.Windows.Forms.ToolStripMenuItem ヘルプHToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem Version_ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem RenameSave_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem DeviceSel_ToolStripMenuItem;
    }
}

