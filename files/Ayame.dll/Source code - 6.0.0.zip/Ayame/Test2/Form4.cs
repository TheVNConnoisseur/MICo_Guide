﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Test2
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        public void ClearDeviceList()
        {
            cmbDevice.Items.Clear();
        }

        public void AddDeviceList(string deviceName)
        {
            cmbDevice.Items.Add(deviceName);
        }

        public void SelectDeviceList(int index)
        {
            cmbDevice.SelectedIndex = index;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
			((Form1)this.Owner).SelectSoundDevice(cmbDevice.SelectedIndex);
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
