﻿namespace Test2
{
	partial class frmMainCtrl
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.mainVolume = new System.Windows.Forms.TrackBar();
			this.chkMute = new System.Windows.Forms.CheckBox();
			this.lbTime = new System.Windows.Forms.Label();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.btnSwStart = new System.Windows.Forms.Button();
			this.btnSwReset = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.mainVolume)).BeginInit();
			this.SuspendLayout();
			// 
			// mainVolume
			// 
			this.mainVolume.AutoSize = false;
			this.mainVolume.Location = new System.Drawing.Point(33, 75);
			this.mainVolume.Maximum = 1000;
			this.mainVolume.Name = "mainVolume";
			this.mainVolume.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.mainVolume.Size = new System.Drawing.Size(47, 184);
			this.mainVolume.TabIndex = 13;
			this.mainVolume.TickFrequency = 100;
			this.mainVolume.TickStyle = System.Windows.Forms.TickStyle.Both;
			this.mainVolume.Value = 1000;
			this.mainVolume.Scroll += new System.EventHandler(this.mainVolume_Scroll);
			// 
			// chkMute
			// 
			this.chkMute.AutoSize = true;
			this.chkMute.Location = new System.Drawing.Point(27, 265);
			this.chkMute.Name = "chkMute";
			this.chkMute.Size = new System.Drawing.Size(57, 16);
			this.chkMute.TabIndex = 14;
			this.chkMute.Text = "ミュート";
			this.chkMute.UseVisualStyleBackColor = true;
			this.chkMute.CheckedChanged += new System.EventHandler(this.chkMute_CheckedChanged);
			// 
			// lbTime
			// 
			this.lbTime.AutoSize = true;
			this.lbTime.Font = new System.Drawing.Font("ＭＳ ゴシック", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
			this.lbTime.Location = new System.Drawing.Point(4, 10);
			this.lbTime.Name = "lbTime";
			this.lbTime.Size = new System.Drawing.Size(106, 21);
			this.lbTime.TabIndex = 15;
			this.lbTime.Text = "00:00:00";
			this.lbTime.Click += new System.EventHandler(this.lbTime_Click);
			// 
			// timer1
			// 
			this.timer1.Enabled = true;
			this.timer1.Interval = 20;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// btnSwStart
			// 
			this.btnSwStart.Location = new System.Drawing.Point(2, 36);
			this.btnSwStart.Name = "btnSwStart";
			this.btnSwStart.Size = new System.Drawing.Size(52, 30);
			this.btnSwStart.TabIndex = 16;
			this.btnSwStart.Text = "スタート";
			this.btnSwStart.UseVisualStyleBackColor = true;
			this.btnSwStart.Click += new System.EventHandler(this.btnSwStart_Click);
			// 
			// btnSwReset
			// 
			this.btnSwReset.Location = new System.Drawing.Point(57, 36);
			this.btnSwReset.Name = "btnSwReset";
			this.btnSwReset.Size = new System.Drawing.Size(52, 30);
			this.btnSwReset.TabIndex = 17;
			this.btnSwReset.Text = "リセット";
			this.btnSwReset.UseVisualStyleBackColor = true;
			this.btnSwReset.Click += new System.EventHandler(this.btnSwReset_Click);
			// 
			// frmMainCtrl
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(112, 295);
			this.ControlBox = false;
			this.Controls.Add(this.btnSwReset);
			this.Controls.Add(this.btnSwStart);
			this.Controls.Add(this.lbTime);
			this.Controls.Add(this.chkMute);
			this.Controls.Add(this.mainVolume);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmMainCtrl";
			this.ShowInTaskbar = false;
			this.Text = "メインパネル";
			this.Load += new System.EventHandler(this.frmMainCtrl_Load);
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmMainCtrl_KeyDown);
			((System.ComponentModel.ISupportInitialize)(this.mainVolume)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TrackBar mainVolume;
		private System.Windows.Forms.CheckBox chkMute;
		private System.Windows.Forms.Label lbTime;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.Button btnSwStart;
		private System.Windows.Forms.Button btnSwReset;
	}
}