﻿namespace Test2
{
	partial class Form2
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.trackBar1 = new System.Windows.Forms.TrackBar();
			this.chkLoop = new System.Windows.Forms.CheckBox();
			this.btnStop = new System.Windows.Forms.Button();
			this.btnPlay = new System.Windows.Forms.Button();
			this.btnOpen = new System.Windows.Forms.Button();
			this.txtFileName = new System.Windows.Forms.TextBox();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.txtName = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.cmbShortCut = new System.Windows.Forms.ComboBox();
			this.btnPause = new System.Windows.Forms.Button();
			this.cmbGroup = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.txtFadeIn = new System.Windows.Forms.TextBox();
			this.txtFadeOut = new System.Windows.Forms.TextBox();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.txtPitch = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.trackBar2 = new System.Windows.Forms.TrackBar();
			this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
			this.panel1 = new System.Windows.Forms.Panel();
			this.btnMini = new System.Windows.Forms.Button();
			this.panel2 = new System.Windows.Forms.Panel();
			this.btnMax = new System.Windows.Forms.Button();
			this.btnPlay2 = new System.Windows.Forms.Button();
			this.btnStop2 = new System.Windows.Forms.Button();
			this.trackBar1B = new System.Windows.Forms.TrackBar();
			this.btnPause2 = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trackBar2)).BeginInit();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.trackBar1B)).BeginInit();
			this.SuspendLayout();
			// 
			// trackBar1
			// 
			this.trackBar1.AutoSize = false;
			this.trackBar1.Location = new System.Drawing.Point(8, 83);
			this.trackBar1.Maximum = 100;
			this.trackBar1.Name = "trackBar1";
			this.trackBar1.Size = new System.Drawing.Size(225, 20);
			this.trackBar1.TabIndex = 12;
			this.trackBar1.TickFrequency = 10;
			this.trackBar1.Value = 100;
			this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
			// 
			// chkLoop
			// 
			this.chkLoop.AutoSize = true;
			this.chkLoop.Location = new System.Drawing.Point(236, 57);
			this.chkLoop.Name = "chkLoop";
			this.chkLoop.Size = new System.Drawing.Size(72, 16);
			this.chkLoop.TabIndex = 11;
			this.chkLoop.Text = "無限Loop";
			this.chkLoop.UseVisualStyleBackColor = true;
			// 
			// btnStop
			// 
			this.btnStop.Location = new System.Drawing.Point(84, 52);
			this.btnStop.Name = "btnStop";
			this.btnStop.Size = new System.Drawing.Size(70, 25);
			this.btnStop.TabIndex = 10;
			this.btnStop.Text = "停止";
			this.btnStop.UseVisualStyleBackColor = true;
			this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
			// 
			// btnPlay
			// 
			this.btnPlay.Location = new System.Drawing.Point(8, 52);
			this.btnPlay.Name = "btnPlay";
			this.btnPlay.Size = new System.Drawing.Size(70, 25);
			this.btnPlay.TabIndex = 9;
			this.btnPlay.Text = "再生";
			this.btnPlay.UseVisualStyleBackColor = true;
			this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
			// 
			// btnOpen
			// 
			this.btnOpen.Location = new System.Drawing.Point(239, 25);
			this.btnOpen.Name = "btnOpen";
			this.btnOpen.Size = new System.Drawing.Size(59, 25);
			this.btnOpen.TabIndex = 8;
			this.btnOpen.Text = "参照";
			this.btnOpen.UseVisualStyleBackColor = true;
			this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
			// 
			// txtFileName
			// 
			this.txtFileName.AllowDrop = true;
			this.txtFileName.Location = new System.Drawing.Point(94, 28);
			this.txtFileName.Name = "txtFileName";
			this.txtFileName.Size = new System.Drawing.Size(139, 19);
			this.txtFileName.TabIndex = 7;
			this.txtFileName.DragDrop += new System.Windows.Forms.DragEventHandler(this.txtFileName_DragDrop);
			this.txtFileName.DragEnter += new System.Windows.Forms.DragEventHandler(this.txtFileName_DragEnter);
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.FileName = "openFileDialog1";
			// 
			// txtName
			// 
			this.txtName.Location = new System.Drawing.Point(41, 4);
			this.txtName.Name = "txtName";
			this.txtName.Size = new System.Drawing.Size(162, 19);
			this.txtName.TabIndex = 13;
			this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(6, 6);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(29, 12);
			this.label1.TabIndex = 14;
			this.label1.Text = "名前";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(209, 6);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(24, 12);
			this.label2.TabIndex = 16;
			this.label2.Text = "Key";
			// 
			// cmbShortCut
			// 
			this.cmbShortCut.AutoCompleteCustomSource.AddRange(new string[] {
            "",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G"});
			this.cmbShortCut.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbShortCut.FormattingEnabled = true;
			this.cmbShortCut.Items.AddRange(new object[] {
            "",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9"});
			this.cmbShortCut.Location = new System.Drawing.Point(237, 3);
			this.cmbShortCut.Name = "cmbShortCut";
			this.cmbShortCut.Size = new System.Drawing.Size(34, 20);
			this.cmbShortCut.TabIndex = 17;
			this.cmbShortCut.SelectedIndexChanged += new System.EventHandler(this.cmbShortCut_SelectedIndexChanged);
			// 
			// btnPause
			// 
			this.btnPause.Location = new System.Drawing.Point(160, 52);
			this.btnPause.Name = "btnPause";
			this.btnPause.Size = new System.Drawing.Size(70, 25);
			this.btnPause.TabIndex = 18;
			this.btnPause.Text = "一時停止";
			this.btnPause.UseVisualStyleBackColor = true;
			this.btnPause.Click += new System.EventHandler(this.btnPause_Click);
			// 
			// cmbGroup
			// 
			this.cmbGroup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbGroup.FormattingEnabled = true;
			this.cmbGroup.Items.AddRange(new object[] {
            "",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N"});
			this.cmbGroup.Location = new System.Drawing.Point(52, 27);
			this.cmbGroup.Name = "cmbGroup";
			this.cmbGroup.Size = new System.Drawing.Size(34, 20);
			this.cmbGroup.TabIndex = 19;
			this.cmbGroup.SelectedIndexChanged += new System.EventHandler(this.cmbGroup_SelectedIndexChanged);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(6, 30);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(43, 12);
			this.label3.TabIndex = 20;
			this.label3.Text = "グループ";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(6, 113);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(57, 12);
			this.label4.TabIndex = 21;
			this.label4.Text = "フェードイン";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(114, 113);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(65, 12);
			this.label5.TabIndex = 22;
			this.label5.Text = "フェードアウト";
			// 
			// txtFadeIn
			// 
			this.txtFadeIn.Location = new System.Drawing.Point(63, 109);
			this.txtFadeIn.Name = "txtFadeIn";
			this.txtFadeIn.Size = new System.Drawing.Size(40, 19);
			this.txtFadeIn.TabIndex = 23;
			this.txtFadeIn.Text = "0";
			this.txtFadeIn.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// txtFadeOut
			// 
			this.txtFadeOut.Location = new System.Drawing.Point(180, 110);
			this.txtFadeOut.Name = "txtFadeOut";
			this.txtFadeOut.Size = new System.Drawing.Size(40, 19);
			this.txtFadeOut.TabIndex = 24;
			this.txtFadeOut.Text = "0";
			this.txtFadeOut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// timer1
			// 
			this.timer1.Interval = 20;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// txtPitch
			// 
			this.txtPitch.Location = new System.Drawing.Point(264, 110);
			this.txtPitch.Name = "txtPitch";
			this.txtPitch.Size = new System.Drawing.Size(40, 19);
			this.txtPitch.TabIndex = 26;
			this.txtPitch.Text = "0";
			this.txtPitch.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(233, 113);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(30, 12);
			this.label6.TabIndex = 25;
			this.label6.Text = "ピッチ";
			// 
			// trackBar2
			// 
			this.trackBar2.AutoSize = false;
			this.trackBar2.Location = new System.Drawing.Point(239, 83);
			this.trackBar2.Maximum = 100;
			this.trackBar2.Minimum = -100;
			this.trackBar2.Name = "trackBar2";
			this.trackBar2.Size = new System.Drawing.Size(65, 20);
			this.trackBar2.TabIndex = 27;
			this.trackBar2.TickFrequency = 10;
			this.trackBar2.Scroll += new System.EventHandler(this.trackBar2_Scroll);
			// 
			// toolTip1
			// 
			this.toolTip1.AutoPopDelay = 5000;
			this.toolTip1.InitialDelay = 0;
			this.toolTip1.ReshowDelay = 100;
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.btnMini);
			this.panel1.Controls.Add(this.cmbGroup);
			this.panel1.Controls.Add(this.trackBar2);
			this.panel1.Controls.Add(this.txtFileName);
			this.panel1.Controls.Add(this.txtPitch);
			this.panel1.Controls.Add(this.btnOpen);
			this.panel1.Controls.Add(this.label6);
			this.panel1.Controls.Add(this.btnPlay);
			this.panel1.Controls.Add(this.txtFadeOut);
			this.panel1.Controls.Add(this.btnStop);
			this.panel1.Controls.Add(this.txtFadeIn);
			this.panel1.Controls.Add(this.chkLoop);
			this.panel1.Controls.Add(this.label5);
			this.panel1.Controls.Add(this.trackBar1);
			this.panel1.Controls.Add(this.label4);
			this.panel1.Controls.Add(this.txtName);
			this.panel1.Controls.Add(this.label3);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.btnPause);
			this.panel1.Controls.Add(this.cmbShortCut);
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(312, 135);
			this.panel1.TabIndex = 28;
			// 
			// btnMini
			// 
			this.btnMini.Location = new System.Drawing.Point(278, 2);
			this.btnMini.Name = "btnMini";
			this.btnMini.Size = new System.Drawing.Size(24, 22);
			this.btnMini.TabIndex = 28;
			this.btnMini.Text = "▲";
			this.btnMini.UseVisualStyleBackColor = true;
			this.btnMini.Click += new System.EventHandler(this.btnMini_Click);
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.btnMax);
			this.panel2.Controls.Add(this.btnPlay2);
			this.panel2.Controls.Add(this.btnStop2);
			this.panel2.Controls.Add(this.trackBar1B);
			this.panel2.Controls.Add(this.btnPause2);
			this.panel2.Location = new System.Drawing.Point(329, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(238, 58);
			this.panel2.TabIndex = 29;
			this.panel2.Visible = false;
			// 
			// btnMax
			// 
			this.btnMax.Location = new System.Drawing.Point(211, 5);
			this.btnMax.Name = "btnMax";
			this.btnMax.Size = new System.Drawing.Size(24, 22);
			this.btnMax.TabIndex = 29;
			this.btnMax.Text = "▼";
			this.btnMax.UseVisualStyleBackColor = true;
			this.btnMax.Click += new System.EventHandler(this.btnMax_Click);
			// 
			// btnPlay2
			// 
			this.btnPlay2.Location = new System.Drawing.Point(3, 4);
			this.btnPlay2.Name = "btnPlay2";
			this.btnPlay2.Size = new System.Drawing.Size(60, 25);
			this.btnPlay2.TabIndex = 19;
			this.btnPlay2.Text = "再生";
			this.btnPlay2.UseVisualStyleBackColor = true;
			this.btnPlay2.Click += new System.EventHandler(this.btnPlay2_Click);
			// 
			// btnStop2
			// 
			this.btnStop2.Location = new System.Drawing.Point(71, 4);
			this.btnStop2.Name = "btnStop2";
			this.btnStop2.Size = new System.Drawing.Size(60, 25);
			this.btnStop2.TabIndex = 20;
			this.btnStop2.Text = "停止";
			this.btnStop2.UseVisualStyleBackColor = true;
			this.btnStop2.Click += new System.EventHandler(this.btnStop2_Click);
			// 
			// trackBar1B
			// 
			this.trackBar1B.AutoSize = false;
			this.trackBar1B.Location = new System.Drawing.Point(3, 31);
			this.trackBar1B.Maximum = 100;
			this.trackBar1B.Name = "trackBar1B";
			this.trackBar1B.Size = new System.Drawing.Size(232, 20);
			this.trackBar1B.TabIndex = 21;
			this.trackBar1B.TickFrequency = 10;
			this.trackBar1B.Value = 100;
			this.trackBar1B.Scroll += new System.EventHandler(this.trackBar1B_Scroll);
			// 
			// btnPause2
			// 
			this.btnPause2.Location = new System.Drawing.Point(139, 4);
			this.btnPause2.Name = "btnPause2";
			this.btnPause2.Size = new System.Drawing.Size(60, 25);
			this.btnPause2.TabIndex = 22;
			this.btnPause2.Text = "一時停";
			this.btnPause2.UseVisualStyleBackColor = true;
			this.btnPause2.Click += new System.EventHandler(this.btnPause2_Click);
			// 
			// Form2
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(597, 145);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.Name = "Form2";
			this.ShowIcon = false;
			this.Load += new System.EventHandler(this.Form2_Load);
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form2_FormClosing);
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form2_KeyDown);
			((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trackBar2)).EndInit();
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.trackBar1B)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TrackBar trackBar1;
		private System.Windows.Forms.CheckBox chkLoop;
		private System.Windows.Forms.Button btnStop;
		private System.Windows.Forms.Button btnPlay;
		private System.Windows.Forms.Button btnOpen;
		private System.Windows.Forms.TextBox txtFileName;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.TextBox txtName;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox cmbShortCut;
		private System.Windows.Forms.Button btnPause;
		private System.Windows.Forms.ComboBox cmbGroup;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox txtFadeIn;
		private System.Windows.Forms.TextBox txtFadeOut;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.TextBox txtPitch;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TrackBar trackBar2;
		private System.Windows.Forms.ToolTip toolTip1;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button btnMini;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Button btnPlay2;
		private System.Windows.Forms.Button btnStop2;
		private System.Windows.Forms.TrackBar trackBar1B;
		private System.Windows.Forms.Button btnPause2;
		private System.Windows.Forms.Button btnMax;
	}
}