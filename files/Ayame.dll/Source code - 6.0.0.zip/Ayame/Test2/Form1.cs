using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using AyameCLR;

namespace Test2
{
    public partial class Form1 : Form
    {
        public	CAyameCLR		m_cAyame;
		public	frmMainCtrl		m_MainCtrlPanel;
		public	string			m_NowProjectName;

		private	uint			m_nVersion;
		private	ProjectSettings	m_Settings;
		private int				m_SoundDeviceIndex;

        public Form1()
        {
            InitializeComponent();
        }

        // ������
        private void Form1_Load(object sender, EventArgs e)
        {
			m_NowProjectName = "";
			m_Settings = new ProjectSettings();
			m_Settings.windowSize = new Size(this.Size.Width, this.Size.Height);
			m_Settings.windowLocation = new Point(this.Location.X, this.Location.Y);
			m_Settings.masterVolume = 100;
			m_Settings.mute = false;

			m_cAyame = new CAyameCLR();

			this.Show();
			if (m_cAyame.LoadDLL(System.Diagnostics.Process.GetCurrentProcess().MainWindowHandle, "ayame.dll") == false)
            {
                MessageBox.Show("Ayame��������܂���ł����B", "�������G���[", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.Close();
                return;
            }
            m_nVersion = m_cAyame.GetVersion();
			toolStripStatusLabel1.Text = string.Format("Ayame DLL Version {0:D}.{1:D}.{2:D}", m_nVersion >> 16, (m_nVersion >> 8) & 255, m_nVersion & 255);

			m_SoundDeviceIndex = 0;
			m_cAyame.SoundDeviceEnumerate();
			m_cAyame.Initialize(m_SoundDeviceIndex);

			m_MainCtrlPanel = new frmMainCtrl();
			m_MainCtrlPanel.MdiParent = this;
			m_MainCtrlPanel.Show();
		}

		protected override void WndProc(ref Message msg)
		{
			const int WM_SYSCOMMAND = 0x0112;
			const int SC_SCREENSAVE = 0xF140;
			const int SC_MONITORPOWER = 0xF170;

			if (msg.Msg == WM_SYSCOMMAND && (msg.WParam.ToInt32() == SC_SCREENSAVE || msg.WParam.ToInt32() == SC_MONITORPOWER))
				return;
			base.WndProc(ref msg);
		}

		private void Form1_DragEnter(object sender, DragEventArgs e)
		{
			if (e.Data.GetDataPresent(DataFormats.FileDrop))
				e.Effect = DragDropEffects.Copy;
			else
				e.Effect = DragDropEffects.None;
		}

		private void Form1_DragDrop(object sender, DragEventArgs e)
		{
			var fileName = (string[])e.Data.GetData(DataFormats.FileDrop, false);
			if (fileName.Length >= 1)
			{
				LoadProject(fileName[0]);
			}
		}

		private void Load_ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			openFileDialog1.FileName = m_NowProjectName;
			DialogResult nResult = openFileDialog1.ShowDialog();
			if (nResult == DialogResult.OK)
			{
				LoadProject(openFileDialog1.FileName);
			}
		}

		// �ۑ�
		private void Save_ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (m_NowProjectName == "") {
				DialogResult nResult = saveFileDialog1.ShowDialog();
				if (nResult != DialogResult.OK)
				{
					return;
				}
				m_NowProjectName = saveFileDialog1.FileName;
			}
			SaveProject(m_NowProjectName);
		}

		// ���O��t���ĕۑ�
		private void RenameSave_ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			DialogResult nResult = saveFileDialog1.ShowDialog();
			if (nResult != DialogResult.OK)
			{
				return;
			}
			m_NowProjectName = saveFileDialog1.FileName;
			SaveProject(m_NowProjectName);
			this.Text = m_NowProjectName;
		}

		// �I��
		private void Quit_ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		// �ǉ�
		private void Add_ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			var	form = new Form2();
			form.MdiParent = this;
			form.Show();
		}

		// �S��~
		private void AllStop_ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			AllStopSound();
		}

		// �o�[�W�������
		private void Version_ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			MessageBox.Show("���ʉ��|���o������\n   Version 1.1.0 2014/08/30\n   Programed by Sazanta");
		}

		// �v���W�F�N�g�̓ǂݍ���
		private void LoadProject(string prjName)
		{
			//XmlSerializer�I�u�W�F�N�g���쐬
			var serializer = new System.Xml.Serialization.XmlSerializer(typeof(ProjectSettings));
			//�ǂݍ��ރt�@�C�����J��
			var fs = new System.IO.FileStream(prjName, System.IO.FileMode.Open);
			//XML�t�@�C������ǂݍ��݁A�t�V���A��������
			m_Settings = (ProjectSettings)serializer.Deserialize(fs);
			//�t�@�C�������
			fs.Close();

			foreach (var form in this.MdiChildren)
			{
				if (form == m_MainCtrlPanel)
				{
					continue;
				}
				form.Close();
			}

			m_NowProjectName = prjName;
			this.Size = m_Settings.windowSize;
			this.Location = m_Settings.windowLocation;
			m_MainCtrlPanel.Location = m_Settings.ctrlLocation;
			m_MainCtrlPanel.SetMasterVolume(m_Settings.masterVolume);
			m_MainCtrlPanel.Mute(m_Settings.mute);
			foreach (var el in m_Settings.element)
			{
				var form = new Form2();
				form.MdiParent = this;
				form.Show();
				form.SetSoundElementInfo(el);
			}
			this.Text = m_NowProjectName;

			if (m_Settings.soundDeviceGuid != null)
			{
				var num = m_cAyame.GetSoundDeviceNum();
				for (var i = 0; i < num; i++)
				{
					var guid = (Guid)m_cAyame.GetSoundDeviceGuid(i);
					if (m_Settings.soundDeviceGuid.Equals(guid.ToString()))
					{
						m_SoundDeviceIndex = i;
						break;
					}
				}
				AllStopSound();
				m_cAyame.Uninitialize();
				m_cAyame.Initialize(m_SoundDeviceIndex);
			}
		}

		// �v���W�F�N�g�̕ۑ�
		private	void	SaveProject(string prjName)
		{
			m_Settings.windowLocation = new Point(this.Location.X, this.Location.Y);
			m_Settings.windowSize = new Size(this.Size.Width, this.Size.Height);
			m_Settings.masterVolume = m_MainCtrlPanel.GetMasterVolume();
			m_Settings.mute = m_MainCtrlPanel.IsMute();

			var element = new List<SoundElement>();
			foreach (var form in this.MdiChildren)
			{
				if (form == m_MainCtrlPanel)
				{
					m_Settings.ctrlLocation = new Point(form.Location.X, form.Location.Y);
					continue;
				}
				element.Add(((Form2)form).GetSoundElementInfo());
			}
			m_Settings.element = element.ToArray();

			var serializer = new System.Xml.Serialization.XmlSerializer(typeof(ProjectSettings));
			//�������ރt�@�C�����J��
			var fs = new System.IO.FileStream(prjName, System.IO.FileMode.Create);
			//�V���A�������AXML�t�@�C���ɕۑ�����
			serializer.Serialize(fs, m_Settings);
			//�t�@�C�������
			fs.Close();
			m_Settings.element = null;
		}

		public void KeyPressProc(char key)
		{
			foreach(var form in this.MdiChildren) {
				if (form == m_MainCtrlPanel) {
					continue;
				}
				if (key == ((Form2)form).GetShortCutKey()) {
					((Form2)form).PlaySound();
				}
			}
		}

		public void AllStopSound()
		{
			foreach (var form in this.MdiChildren)
			{
				if (form == m_MainCtrlPanel)
				{
					continue;
				}
				((Form2)form).StopSound();
			}
		}

		// �w�肵���O���[�v�̉����~�߂�
		public void StopSound(int group, Form2 expect)
		{
			if (group == 0) {
				return;
			}
			foreach (var form in this.MdiChildren)
			{
				if (form == m_MainCtrlPanel || form == expect)
				{
					continue;
				}
				if (((Form2)form).GetGroupNo() == group) {
					((Form2)form).StopSound();
				}
			}
		}

		public void ReflectAllElement()
		{
			foreach (var form in this.MdiChildren)
			{
				if (form == m_MainCtrlPanel)
				{
					continue;
				}
				((Form2)form).ReflectVolume();
			}
		}

		private void DeviceSel_ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			var form4 = new Form4();
			form4.Owner = this;
			form4.ClearDeviceList();
			var	num = m_cAyame.GetSoundDeviceNum();
			for (var i = 0; i < num; i++)
			{
				form4.AddDeviceList(m_cAyame.GetSoundDeviceDesc(i));
			}
			form4.SelectDeviceList(m_SoundDeviceIndex);
			form4.ShowDialog();
		}

		public void SelectSoundDevice(int index)
		{
			m_SoundDeviceIndex = index;
			var guid = (Guid)m_cAyame.GetSoundDeviceGuid(index);
			m_Settings.soundDeviceGuid = guid.ToString();
			AllStopSound();
			m_cAyame.Uninitialize();
			m_cAyame.Initialize(m_SoundDeviceIndex);
		}
	}
}