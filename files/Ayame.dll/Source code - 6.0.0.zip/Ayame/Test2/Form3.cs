﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Test2
{
	public partial class frmMainCtrl : Form
	{
		private	bool	m_TimerIsStopWatch;
		private	System.Diagnostics.Stopwatch	m_StopWatch = System.Diagnostics.Stopwatch.StartNew();

		public frmMainCtrl()
		{
			InitializeComponent();
			m_TimerIsStopWatch = false;
			m_StopWatch.Reset();
		}

		private void frmMainCtrl_Load(object sender, EventArgs e)
		{
		}

		private void frmMainCtrl_KeyDown(object sender, KeyEventArgs e)
		{
			((Form1)this.MdiParent).KeyPressProc(Convert.ToChar(e.KeyCode));
		}

		private void mainVolume_Scroll(object sender, EventArgs e)
		{
			((Form1)this.MdiParent).ReflectAllElement();
		}

		private void chkMute_CheckedChanged(object sender, EventArgs e)
		{
			((Form1)this.MdiParent).ReflectAllElement();
		}

		private void lbTime_Click(object sender, EventArgs e)
		{
			m_TimerIsStopWatch = !m_TimerIsStopWatch;
		}

		private void btnSwStart_Click(object sender, EventArgs e)
		{
			if (m_TimerIsStopWatch == false) {
				m_TimerIsStopWatch = true;
			}
			if (m_StopWatch.IsRunning) {
				m_StopWatch.Stop();
				btnSwStart.Text = "スタート";
			} else {
				m_StopWatch.Start();
				btnSwStart.Text = "ストップ";
			}
		}

		private void btnSwReset_Click(object sender, EventArgs e)
		{
			if (m_TimerIsStopWatch == false) {
				m_TimerIsStopWatch = true;
			}
			m_StopWatch.Reset();
			btnSwStart.Text = "スタート";
		}

		public void SetMasterVolume(int value)
		{
			mainVolume.Value = value;
		}
		public int GetMasterVolume()
		{
			return mainVolume.Value;
		}

		public void Mute(bool sw)
		{
			chkMute.Checked = sw;
		}
		public bool IsMute()
		{
			return chkMute.Checked;
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			if (m_TimerIsStopWatch == false) {
				DateTime	now = DateTime.Now;
				lbTime.Text = string.Format("{0:D2}:{1:D2}:{2:D2}", now.Hour, now.Minute, now.Second);
			}
			else
			{
				long time = m_StopWatch.ElapsedMilliseconds;
				lbTime.Text = string.Format("{0:D2}:{1:D2}:{2:D2}", time / (1000 * 60), (time / 1000) % 60, (time / 10) % 100);
			}
		}
	}
}
