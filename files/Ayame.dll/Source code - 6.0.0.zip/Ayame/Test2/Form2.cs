﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Web;

namespace Test2
{
	public partial class Form2 : Form
	{
        private	IntPtr			m_pAyame;
		private	SoundElement	m_Info;
		private	int				m_FadeProc;
		private	long			m_FadeStartTime;
		private long			m_FadeEndTime;

		public Form2()
		{
			InitializeComponent();
		}

		private void Form2_Load(object sender, EventArgs e)
		{
            m_pAyame = IntPtr.Zero;
			m_Info = new SoundElement();
			m_Info.volume = 100;
			txtPitch.Text = "1";
			cmbShortCut.SelectedIndex = 0;
			cmbGroup.SelectedIndex = 0;
			panel2.Location = new Point(0, 0);
			this.Size = new Size(panel1.Size.Width + 5, panel1.Size.Height + SystemInformation.CaptionHeight + 5);
		}

		private void Form2_FormClosing(object sender, FormClosingEventArgs e)
		{
			StopSound();
		}

		// フェードタイマー
		private void timer1_Tick(object sender, EventArgs e)
		{
			ReflectVolume();
		}

		private void txtFileName_DragEnter(object sender, DragEventArgs e)
		{
			if (e.Data.GetDataPresent(DataFormats.FileDrop))
				e.Effect = DragDropEffects.Copy;
			else
				e.Effect = DragDropEffects.None;
		}

		private void txtFileName_DragDrop(object sender, DragEventArgs e)
		{
			var fileName = (string[])e.Data.GetData(DataFormats.FileDrop, false);
			if (fileName.Length >= 1)
			{
		        SetFile(fileName[0]);
			}
		}

		private void txtName_TextChanged(object sender, EventArgs e)
		{
			SetTitle();
		}

		private void cmbShortCut_SelectedIndexChanged(object sender, EventArgs e)
		{
			SetTitle();
		}

		private void cmbGroup_SelectedIndexChanged(object sender, EventArgs e)
		{
			SetTitle();
		}

		private void btnOpen_Click(object sender, EventArgs e)
		{
			openFileDialog1.FileName = txtFileName.Text;
            DialogResult    nResult = openFileDialog1.ShowDialog();
            if (nResult == DialogResult.OK)
            {
		        SetFile(openFileDialog1.FileName);
            }
		}

		private void btnPlay_Click(object sender, EventArgs e)
		{
			PlaySound();
		}

		private void btnPlay2_Click(object sender, EventArgs e)
		{
			PlaySound();
		}

		private void btnPause_Click(object sender, EventArgs e)
		{
			if (m_pAyame != IntPtr.Zero)
			{
				((Form1)this.MdiParent).m_cAyame.Pause(m_pAyame);
			}
		}

		private void btnPause2_Click(object sender, EventArgs e)
		{
			if (m_pAyame != IntPtr.Zero)
			{
				((Form1)this.MdiParent).m_cAyame.Pause(m_pAyame);
			}
		}

		private void btnStop_Click(object sender, EventArgs e)
		{
			StopSound();
		}

		private void btnStop2_Click(object sender, EventArgs e)
		{
			StopSound();
		}

		private void trackBar1_Scroll(object sender, EventArgs e)
		{
			int val = ((System.Windows.Forms.TrackBar)sender).Value;
			trackBar1B.Value = val;
			m_Info.volume = val;
			toolTip1.SetToolTip(trackBar1, val.ToString());
			ReflectVolume();
		}

		private void trackBar1B_Scroll(object sender, EventArgs e)
		{
			int val = ((System.Windows.Forms.TrackBar)sender).Value;
			trackBar1.Value = val;
			m_Info.volume = val;
			toolTip1.SetToolTip(trackBar1, val.ToString());
			ReflectVolume();
		}

		private void trackBar2_Scroll(object sender, EventArgs e)
		{
			((Form1)this.MdiParent).m_cAyame.SetPan(m_pAyame, trackBar2.Value);
			toolTip1.SetToolTip(trackBar2, trackBar2.Value.ToString());
		}

		private void btnMini_Click(object sender, EventArgs e)
		{
			SetWindowMode(true);
		}

		private void btnMax_Click(object sender, EventArgs e)
		{
			SetWindowMode(false);
		}

		void SetFile(string filePath)
		{
			txtFileName.Text = filePath;

			Uri	u1 = new Uri(((Form1)this.MdiParent).m_NowProjectName);
			Uri	u2 = new Uri(filePath);
			Uri	relativeUri = u1.MakeRelativeUri(u2);
			string	relativePath = HttpUtility.UrlDecode(relativeUri.ToString()).Replace('/', '\\');
			m_Info.filePath    = filePath;
			m_Info.filePathRel = relativePath;
		}
		
		void SetTitle()
		{
			string	txt = "";
			if (cmbShortCut.SelectedIndex != 0) {
				txt += cmbShortCut.Items[cmbShortCut.SelectedIndex].ToString() + ":";
			}
			if (cmbGroup.SelectedIndex > 0)
			{
				txt += "(" + cmbGroup.Items[cmbGroup.SelectedIndex].ToString() + ")";
			}
			txt += txtName.Text;
			this.Text = txt;
		}

		public int GetGroupNo()
		{
			return cmbGroup.SelectedIndex;
		}

		public char GetShortCutKey()
		{
			return cmbShortCut.SelectedIndex == 0? (char)0 : Char.Parse(cmbShortCut.Items[cmbShortCut.SelectedIndex].ToString());
		}

		public void SetWindowMode(bool min)
		{
			if (min) {
				panel1.Visible = false;
				panel2.Visible = true;
				this.Size = new Size(panel2.Size.Width + 5, panel2.Size.Height + SystemInformation.CaptionHeight + 5);
				btnMax.Focus();
			} else {
				panel1.Visible = true;
				panel2.Visible = false;
				this.Size = new Size(panel1.Size.Width + 5, panel1.Size.Height + SystemInformation.CaptionHeight + 5);
				btnMini.Focus();
			}
		}

		// 再生
		public void PlaySound()
		{
			// 同じグループの音を止める
			((Form1)this.MdiParent).StopSound(GetGroupNo(), this);

            if (m_pAyame != IntPtr.Zero)
            {
				
    			((Form1)this.MdiParent).m_cAyame.Release(m_pAyame);
                m_pAyame = IntPtr.Zero;
            }
			float	pitch = 1;
			float.TryParse(txtPitch.Text, out pitch);
            m_pAyame = ((Form1)this.MdiParent).m_cAyame.CreateInstanceFromFile(txtFileName.Text, 0, 0, 1);
            ((Form1)this.MdiParent).m_cAyame.Play(m_pAyame, (chkLoop.Checked == false)? 0 : 0xffffffff, 0, 0);
			((Form1)this.MdiParent).m_cAyame.SetPan(m_pAyame, trackBar2.Value);
			((Form1)this.MdiParent).m_cAyame.SetFrequencyRate(m_pAyame, pitch);
			float fade = 0;
			float.TryParse(txtFadeIn.Text, out fade);
			if (fade == 0) {
				ReflectVolume();
				m_FadeProc = 0;
			} else {
				m_FadeProc = 1;
				m_FadeStartTime = DateTime.Now.Ticks;
				m_FadeEndTime = m_FadeStartTime + (long)(fade * 10000000);
				((Form1)this.MdiParent).m_cAyame.SetVolume(m_pAyame, 0);
				timer1.Enabled = true;
			}
		}

		// 停止
		public void StopSound()
		{
			if (m_pAyame != IntPtr.Zero && m_FadeProc != 2)
            {
				float fade = 0;
				float.TryParse(txtFadeOut.Text, out fade);
				if (fade == 0) {
					((Form1)this.MdiParent).m_cAyame.Release(m_pAyame);
					m_pAyame = IntPtr.Zero;
					m_FadeProc = 0;
				}
				else
				{
					m_FadeProc = 2;
					m_FadeStartTime = DateTime.Now.Ticks;
					m_FadeEndTime = m_FadeStartTime + (long)(fade * 10000000);
					timer1.Enabled = true;
				}
			}
		}

		// ボリュームの反映
		public void ReflectVolume()
		{
			if (m_pAyame == IntPtr.Zero)
			{
				return;
			}

			float vol = ((Form1)this.MdiParent).m_MainCtrlPanel.IsMute()? 0 : trackBar1.Value;
			vol *= ((Form1)this.MdiParent).m_MainCtrlPanel.GetMasterVolume();
			vol /= 1000f;
			if (m_FadeProc == 1)
			{
				// FadeIn
				long now = DateTime.Now.Ticks;
				if (now >= m_FadeEndTime)
				{
					m_FadeProc = 0;
					timer1.Enabled = false;
				}
				else
				{
					vol *= (now - m_FadeStartTime);
					vol /= (m_FadeEndTime - m_FadeStartTime);
				}
			}
			else if (m_FadeProc == 2)
			{
				// FadeOut
				long now = DateTime.Now.Ticks;
				if (now >= m_FadeEndTime)
				{
					((Form1)this.MdiParent).m_cAyame.Release(m_pAyame);
					m_pAyame = IntPtr.Zero;
					m_FadeProc = 0;
					timer1.Enabled = false;
					return;
				}
				else
				{
					vol = vol - (vol * (now - m_FadeStartTime) / (float)(m_FadeEndTime - m_FadeStartTime));
				}
			}
			((Form1)this.MdiParent).m_cAyame.SetVolume(m_pAyame, vol);
		}

		public SoundElement GetSoundElementInfo()
		{
			m_Info.windowLocation = this.Location;
			m_Info.groupNo = cmbGroup.SelectedIndex;
			m_Info.name = txtName.Text;
			m_Info.filePath = txtFileName.Text;
			m_Info.shortCutKey = cmbShortCut.SelectedIndex;
			m_Info.loop = chkLoop.Checked;
			m_Info.volume = trackBar1.Value;
			m_Info.pan = trackBar2.Value;
			m_Info.fadeinTime = float.Parse(txtFadeIn.Text);
			m_Info.fadeoutTime = float.Parse(txtFadeOut.Text);
			m_Info.pitch = float.Parse(txtPitch.Text);
			m_Info.minMode = panel2.Visible;

			return m_Info;
		}

		public void SetSoundElementInfo(SoundElement info)
		{
			m_Info = info;
			this.Location = info.windowLocation;
			cmbGroup.SelectedIndex = info.groupNo;
			cmbShortCut.SelectedIndex = info.shortCutKey;
			txtName.Text = info.name;
			txtFileName.Text = info.filePath;
			if (!File.Exists(info.filePath)) {
				Uri	u1 = new Uri(((Form1)this.MdiParent).m_NowProjectName);
				Uri	u2 = new Uri(u1, info.filePathRel);
				var	filePath = u2.ToString().Replace("file:///", "");
				filePath = HttpUtility.UrlDecode(filePath).Replace('/', '\\');
				if (File.Exists(filePath)) {
					txtFileName.Text = filePath;
				}
			}
			txtFadeIn.Text = info.fadeinTime.ToString();
			txtFadeOut.Text = info.fadeoutTime.ToString();
			txtPitch.Text = info.pitch.ToString();
			chkLoop.Checked = info.loop;
			trackBar1.Value = info.volume;
			trackBar1B.Value = info.volume;
			trackBar2.Value = info.pan;
			SetWindowMode(info.minMode);
		}

		private void Form2_KeyDown(object sender, KeyEventArgs e)
		{
			var	ctrlType = this.ActiveControl.GetType();
			if (ctrlType != txtName.GetType() && ctrlType != cmbShortCut.GetType()) {
				((Form1)this.MdiParent).KeyPressProc(Convert.ToChar(e.KeyCode));
			}
		}
	}
}
