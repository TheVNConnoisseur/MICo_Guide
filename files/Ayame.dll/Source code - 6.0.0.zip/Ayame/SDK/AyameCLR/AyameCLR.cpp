// ����� ���C�� DLL �t�@�C���ł��B

#include "AyameCLR.h"

delegate bool EnumerateCallback(LPGUID lpGUID, LPCTSTR lpszDesc, LPCTSTR lpszDrvName, LPVOID lpContext);

namespace AyameCLR
{

CAyameCLR::CAyameCLR()
{
	m_hWnd = IntPtr::Zero;
	m_hAyame = NULL;
	m_pAyameGetVersion = NULL;
	m_pAyameDeviceEnumerate = NULL;
	m_pAyameInitialize = NULL;
	m_pAyameUninitialize = NULL;
	m_pAyameGetDirectSoundCaps = NULL;
	m_pAyameCreateFromFile = NULL;
	m_pAyameCreateFromMemory = NULL;
	m_pAyameCreateFromUrl = NULL;
	m_pAyameGetError = NULL;
}


//! Ayame�̓ǂݍ��݂Ə�����
/**
 *	Ayame.dll�̓ǂݍ��݂�DirectSound�̏��������s���܂��B
 *	�C���X�^���X�쐬���Ɉ�x�����Ăяo���Ă��������B
 */
bool	CAyameCLR::LoadDLL(IntPtr hWnd, System::String ^path)
{
	if (m_hAyame != NULL) {
		return false;
	}
	// DLL�̃��[�h
	IntPtr tptr = Marshal::StringToHGlobalUni(path);
	m_hAyame = ::LoadLibrary((LPCWSTR)tptr.ToPointer());
	if (m_hAyame == NULL)	return false;

	// �֐��̃��[�h
	m_pAyameGetVersion			= (AYAME_GETVERSION_PROC)::GetProcAddress(m_hAyame, "Ayame_GetVersion");
	m_pAyameDeviceEnumerate     = (AYAME_DIRECTSOUNDENUMERATE_PROC)::GetProcAddress(m_hAyame, "Ayame_DirectSoundEnumerate");
	m_pAyameInitialize			= (AYAME_INITIALIZE_PROC)::GetProcAddress(m_hAyame, "Ayame_Initialize");
	m_pAyameUninitialize		= (AYAME_UNINITIALIZE_PROC)::GetProcAddress(m_hAyame, "Ayame_Uninitialize");
	m_pAyameGetDirectSoundCaps	= (AYAME_GETDIRECTSOUNDCAPS_PROC)::GetProcAddress(m_hAyame, "Ayame_GetDirectSoundCaps");
	m_pAyameCreateFromFile		= (AYAME_CREATE_FROM_FILE_PROC)::GetProcAddress(m_hAyame, "Ayame_CreateInstanceFromFile");
	m_pAyameCreateFromMemory	= (AYAME_CREATE_FROM_MEMORY_PROC)::GetProcAddress(m_hAyame, "Ayame_CreateInstanceFromMemory");
	m_pAyameCreateFromUrl       = (AYAME_CREATE_FROM_URL_PROC)::GetProcAddress(m_hAyame, "Ayame_CreateInstanceFromUrl");
	m_pAyameGetError			= (AYAME_GETERROR_PROC)::GetProcAddress(m_hAyame, "Ayame_GetLastError");

	if ( m_pAyameGetVersion			== NULL ||
		 m_pAyameDeviceEnumerate	== NULL ||
		 m_pAyameInitialize			== NULL ||
		 m_pAyameUninitialize		== NULL ||
		 m_pAyameGetDirectSoundCaps	== NULL ||
		 m_pAyameCreateFromFile		== NULL ||
		 m_pAyameCreateFromMemory	== NULL ||
		 m_pAyameCreateFromUrl		== NULL ||
		 m_pAyameGetError			== NULL ) {
		::FreeLibrary(m_hAyame);
		m_hAyame = NULL;
		return false;
	}
	m_hWnd = hWnd;

	return true;
}


//! AyameDLL�̃o�[�W�����̎擾
/**
 *	AyameDLL�̃o�[�W�������擾���܂��B
 */
DWORD	CAyameCLR::GetVersion()
{
	return (m_pAyameGetVersion == NULL)? 0 : m_pAyameGetVersion();
}


//! �T�E���h�f�o�C�X�̗�
void	CAyameCLR::SoundDeviceEnumerate()
{
	if (m_pAyameDeviceEnumerate != NULL) {
		m_SoundDeviceGuid.Clear();
		m_SoundDeviceDesc.Clear();
		GCHandle			handle  = GCHandle::Alloc(this);
		IntPtr				pointer = GCHandle::ToIntPtr(handle);
		EnumerateCallback^	cb = gcnew EnumerateCallback(EnumerateCallback_f);
		m_pAyameDeviceEnumerate(static_cast<LPDSENUMCALLBACK>(Marshal::GetFunctionPointerForDelegate(cb).ToPointer()), pointer.ToPointer());
		handle.Free();
	}
}

//! �񋓂����T�E���h�f�o�C�X���̎擾
int	CAyameCLR::GetSoundDeviceNum()
{
	return m_SoundDeviceGuid.Count;
}

//! �񋓂����T�E���h�f�o�C�X��GUID�擾
System::Guid^	CAyameCLR::GetSoundDeviceGuid(int index)
{
	if (0 > index || index >= m_SoundDeviceDesc.Count) {
		return Guid(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
	} else {
		return m_SoundDeviceGuid[index];
	}
}

//! �񋓂����T�E���h�f�o�C�X�̐����擾
System::String^	CAyameCLR::GetSoundDeviceDesc(int index)
{
	return (0 > index || index >= m_SoundDeviceDesc.Count)? L"" : m_SoundDeviceDesc[index];
}

bool	CAyameCLR::EnumerateCallback_f(LPGUID lpGUID, LPCTSTR lpszDesc, LPCTSTR lpszDrvName, LPVOID lpContext)
{
	IntPtr			pointer(lpContext);
	GCHandle		handle = GCHandle::FromIntPtr(pointer);
	CAyameCLR^		obj = (CAyameCLR^)handle.Target;

	if (lpGUID != NULL) {
		obj->m_SoundDeviceGuid.Add(Guid(lpGUID->Data1, lpGUID->Data2, lpGUID->Data3,
					lpGUID->Data4[0], lpGUID->Data4[1], lpGUID->Data4[2], lpGUID->Data4[3],
					lpGUID->Data4[4], lpGUID->Data4[5], lpGUID->Data4[6], lpGUID->Data4[7]));
	} else {
		obj->m_SoundDeviceGuid.Add(Guid(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0));
	}
	obj->m_SoundDeviceDesc.Add(gcnew String(lpszDesc));

	return true;
}


//! DirectSound�̏�����
/**
 *	DirectSound�̏��������s���܂��B
 */
bool	CAyameCLR::Initialize(int guidIndex)
{
	if (m_hWnd == IntPtr::Zero) {
		return false;
	}

	if (guidIndex <= 0 || guidIndex >= m_SoundDeviceGuid.Count) {
		return m_pAyameInitialize(m_hWnd, NULL, NULL);
	} else {
		array<Byte>^	guidData = m_SoundDeviceGuid[guidIndex].ToByteArray();
		pin_ptr<Byte>	data = &(guidData[0]);

		return m_pAyameInitialize(m_hWnd, NULL, (LPCGUID)data);
	}
}


//! DirectSound�̏I������
/**
 *	DirectSound�̏I���������s���܂��B
 *	�ʏ�̓C���X�^���X������Ɏ����I�ɌĂ΂��̂ŁA�ʂɌĂяo���K�v�͂���܂���B
 */
void	CAyameCLR::Uninitialize()
{
	m_pAyameUninitialize();
}


//! Ayame�̊J��
/**
 *	Ayame.dll�̏I���������s���܂��B
 *	�ʏ�̓C���X�^���X������Ɏ����I�ɌĂ΂��̂ŁA�ʂɌĂяo���K�v�͂���܂���B
 */
void	CAyameCLR::Release()
{
	if (m_hAyame != NULL) {
		m_pAyameUninitialize();
		::FreeLibrary(m_hAyame);
		m_hAyame = NULL;
	}
}


IntPtr	CAyameCLR::CreateInstanceFromFile(System::String ^path, unsigned long Start, unsigned long Size, unsigned long Flag)
{
	if (m_hAyame == NULL) {
		return IntPtr::Zero;
	}
	IntPtr tptr;
	#ifdef _UNICODE
	tptr = Marshal::StringToHGlobalUni(path);
	#else
	tptr = Marshal::StringToHGlobalAnsi(path);
	#endif

	return (IntPtr)m_pAyameCreateFromFile((char*)tptr.ToPointer(), Start, Size, Flag);
}


IntPtr	CAyameCLR::CreateInstanceFromMemory(array<Byte> ^pData, unsigned long Flag)
{
	if (m_hAyame == NULL || pData->Length == 0) {
		return IntPtr::Zero;
	}
	pin_ptr<Byte>	pByte = &pData[0];

	return (IntPtr)m_pAyameCreateFromMemory(pByte, pData->Length, Flag);
}


IntPtr	CAyameCLR::CreateInstanceFromUrl(System::String ^path, unsigned long Start, unsigned long Size, unsigned long Flag)
{
	if (m_hAyame == NULL) {
		return IntPtr::Zero;
	}
	IntPtr tptr;
	#ifdef _UNICODE
	tptr = Marshal::StringToHGlobalUni(path);
	#else
	tptr = Marshal::StringToHGlobalAnsi(path);
	#endif

	return (IntPtr)m_pAyameCreateFromUrl((char*)tptr.ToPointer(), Start, Size, Flag);
}


bool	CAyameCLR::IsReady(IntPtr pInst)
{
	CAyame*	pAyame = (CAyame*)pInst.ToPointer();

	return (pAyame == NULL)? false : pAyame->IsReady();
}


bool	CAyameCLR::IsNotDecoder(IntPtr pInst)
{
	CAyame*	pAyame = (CAyame*)pInst.ToPointer();

	return (pAyame == NULL)? false : pAyame->IsNotDecoder();
}


bool	CAyameCLR::IsPlayStarted(IntPtr pInst)
{
	CAyame*	pAyame = (CAyame*)pInst.ToPointer();

	return (pAyame == NULL)? false : pAyame->IsPlayStarted();
}


bool	CAyameCLR::IsPlay(IntPtr pInst)
{
	CAyame*	pAyame = (CAyame*)pInst.ToPointer();

	return (pAyame == NULL)? false : pAyame->IsPlay();
}


bool	CAyameCLR::IsPause(IntPtr pInst)
{
	CAyame*	pAyame = (CAyame*)pInst.ToPointer();

	return (pAyame == NULL)? false : pAyame->IsPause();
}


bool	CAyameCLR::Prefetch(IntPtr pInst)
{
	CAyame*	pAyame = (CAyame*)pInst.ToPointer();

	return (pAyame == NULL)? false : pAyame->Prefetch();
}


bool	CAyameCLR::Predecode(IntPtr pInst)
{
	CAyame*	pAyame = (CAyame*)pInst.ToPointer();

	return (pAyame == NULL)? false : pAyame->Predecode();
}


bool	CAyameCLR::Play(IntPtr pInst, unsigned long nLoop, unsigned long nLoopInSample, unsigned long nStartPos)
{
	CAyame*	pAyame = (CAyame*)pInst.ToPointer();

	return (pAyame == NULL)? false : pAyame->Play(nLoop, nLoopInSample, nStartPos);
}


bool	CAyameCLR::Stop(IntPtr pInst)
{
	CAyame*	pAyame = (CAyame*)pInst.ToPointer();

	return (pAyame == NULL)? false : pAyame->Stop();
}


bool	CAyameCLR::Pause(IntPtr pInst)
{
	CAyame*	pAyame = (CAyame*)pInst.ToPointer();

	return (pAyame == NULL)? false : pAyame->Pause();
}


bool	CAyameCLR::SetVolume(IntPtr pInst, float fParam)
{
	CAyame*	pAyame = (CAyame*)pInst.ToPointer();

	return (pAyame == NULL)? false : pAyame->SetVolume(fParam);
}


bool	CAyameCLR::SetPan(IntPtr pInst, float fParam)
{
	CAyame*	pAyame = (CAyame*)pInst.ToPointer();

	return (pAyame == NULL)? false : pAyame->SetPan(fParam);
}


bool	CAyameCLR::SetFrequencyRate(IntPtr pInst, float fParam)
{
	CAyame*	pAyame = (CAyame*)pInst.ToPointer();

	return (pAyame == NULL)? false : pAyame->SetFrequencyRate(fParam);
}


bool	CAyameCLR::Release(IntPtr pInst)
{
	CAyame*	pAyame = (CAyame*)pInst.ToPointer();

	return (pAyame == NULL)? false : pAyame->Release();
}


unsigned long	CAyameCLR::GetPlayingPoint(IntPtr pInst)
{
	CAyame*	pAyame = (CAyame*)pInst.ToPointer();

	return (pAyame == NULL)? 0 : pAyame->GetPlayingPoint();
}


unsigned long	CAyameCLR::GetTotalSample(IntPtr pInst)
{
	CAyame*	pAyame = (CAyame*)pInst.ToPointer();

	return (pAyame == NULL)? 0 : pAyame->GetTotalSample();
}


}		// namespace AyameCLR
/*  Bottom of AyameCLR.cpp  */
