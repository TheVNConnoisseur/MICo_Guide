// AyameCLR.h

#pragma once

#include	<windows.h>
#include	"dsound.h"

using namespace System;
using namespace System::Collections::Generic;
using namespace	System::Runtime::InteropServices;

typedef DWORD			(__stdcall *AYAME_GETVERSION_PROC)( void );																						///< �o�[�W�����擾
typedef void			(__stdcall *AYAME_DIRECTSOUNDENUMERATE_PROC)(LPDSENUMCALLBACK callback, LPVOID  lpContext);
typedef	bool			(__stdcall *AYAME_INITIALIZE_PROC)(IntPtr hWnd, void **ppDirectSound, LPCGUID lpcGuid);															///< �h���C�o�[������
typedef void			(__stdcall *AYAME_UNINITIALIZE_PROC)(void);																						///< �h���C�o�[���
typedef bool			(__stdcall *AYAME_GETDIRECTSOUNDCAPS_PROC)( DSCAPS* pCaps );																	///< Caps�擾
typedef bool			(__stdcall *AYAME_GETERROR_PROC)(char *pErrStr, unsigned long Size);															///< �G���[�擾
typedef class CAyame*	(__stdcall *AYAME_CREATE_FROM_FILE_PROC)(const char *pFileName, unsigned long Start, unsigned long Size, unsigned long Flag);	///< �h���C�o�[����I�u�W�F�N�g�擾
typedef class CAyame*	(__stdcall *AYAME_CREATE_FROM_MEMORY_PROC)(void *pData, unsigned long Size, unsigned long Flag);								///< �h���C�o�[����I�u�W�F�N�g�擾
typedef class CAyame*	(__stdcall *AYAME_CREATE_FROM_URL_PROC)(const char *pUrl, unsigned long Start, unsigned long Size, unsigned long Flag);			///< �h���C�o�[����I�u�W�F�N�g�擾


class CAyame
{
protected:
	virtual ~CAyame(){}												///< �f�X�g���N�^
public:
	virtual bool __stdcall IsEmptyQueue( void )				= 0;	///< �L���[�ɓo�^�����邩�ǂ���
	virtual bool __stdcall IsReady( void ) const			= 0;	///< �����������ς݂��H
	virtual bool __stdcall IsNotDecoder( void ) const		= 0;	///< �f�R�[�_�����݂��邩�ǂ����H
	virtual bool __stdcall IsPlayStarted( void ) const		= 0;	///< �Đ��J�n�`�F�b�N
	virtual bool __stdcall IsPlay( void ) const				= 0;	///< �Đ��`�F�b�N
	virtual bool __stdcall IsPause( void ) const			= 0;	///< �ꎞ��~���`�F�b�N
	virtual bool __stdcall Prefetch( void )					= 0;	///< �v���t�F�b�`
	virtual bool __stdcall Predecode( void )				= 0;	///< �v���f�R�[�h
	virtual bool __stdcall Combine( CAyame *pAyame )		= 0;	///< �A��
	virtual bool __stdcall Play( unsigned long nLoopCount = 0, unsigned long nLoopInSample = 0, unsigned long nStartPos = 0 )	= 0;	///< �Đ�
	virtual bool __stdcall Stop( void )						= 0;	///< ��~
	virtual bool __stdcall Pause( void )					= 0;	///< �ꎞ��~
	virtual bool __stdcall SetVolume( float fParam )		= 0;	///< �{�����[���ݒ�
	virtual bool __stdcall SetPan( float fParam )			= 0;	///< �p���ݒ�
	virtual bool __stdcall SetFrequencyRate( float fParam )	= 0;	///< ���g���ݒ�
	virtual bool __stdcall Release( void )					= 0;	///< ���
	virtual bool __stdcall AddRef( void )					= 0;	///< �Q�ƃJ�E���g�C���N�������g
	virtual unsigned long __stdcall GetPlayingPoint( void )	= 0;	///< �����悻�̍Đ��ʒu�̎擾
	virtual unsigned long __stdcall GetTotalSample( void )	= 0;	///< �g�[�^���̃T���v�����̎擾
};


namespace AyameCLR
{
	public ref class CAyameCLR
	{
		public:
			static	unsigned long	AYAME_LOOP_INFINITY		= (0xFFFFFFFF);	///< �������[�v
			static	unsigned long	AYAME_LOADFLAG_GLOBAL	= (1<<0);
			static	unsigned long	AYAME_LOADFLAG_STREAM	= (0<<1);
			static	unsigned long	AYAME_LOADFLAG_STATIC	= (1<<1);

	private:
			IntPtr							m_hWnd;
			HINSTANCE						m_hAyame;
			AYAME_GETVERSION_PROC			m_pAyameGetVersion;
			AYAME_DIRECTSOUNDENUMERATE_PROC	m_pAyameDeviceEnumerate;
			AYAME_INITIALIZE_PROC			m_pAyameInitialize;
			AYAME_UNINITIALIZE_PROC			m_pAyameUninitialize;
			AYAME_GETDIRECTSOUNDCAPS_PROC	m_pAyameGetDirectSoundCaps;
			AYAME_CREATE_FROM_FILE_PROC		m_pAyameCreateFromFile;
			AYAME_CREATE_FROM_MEMORY_PROC	m_pAyameCreateFromMemory;
			AYAME_CREATE_FROM_URL_PROC		m_pAyameCreateFromUrl;
			AYAME_GETERROR_PROC				m_pAyameGetError;
			List<System::Guid>				m_SoundDeviceGuid;
			List<System::String^>			m_SoundDeviceDesc;

	static	bool			EnumerateCallback_f(LPGUID lpGUID, LPCTSTR lpszDesc, LPCTSTR lpszDrvName, LPVOID lpContext);

		public:
							CAyameCLR();
							~CAyameCLR() {
								this->!CAyameCLR();
							}
							!CAyameCLR() {
								Release();
							}

			bool			LoadDLL(IntPtr hWnd, System::String ^path);

			DWORD			GetVersion();

			void			SoundDeviceEnumerate();
			int				GetSoundDeviceNum();
			System::Guid^	GetSoundDeviceGuid(int index);
			System::String^	GetSoundDeviceDesc(int index);

			bool			Initialize(int guidIndex);
			void			Uninitialize();
			void			Release();

			IntPtr			CreateInstanceFromFile(System::String ^path, unsigned long Start, unsigned long Size, unsigned long Flag);
			IntPtr			CreateInstanceFromMemory(array<Byte> ^pData, unsigned long Flag);
			IntPtr			CreateInstanceFromUrl(System::String ^path, unsigned long Start, unsigned long Size, unsigned long Flag);

			bool			IsReady(IntPtr pInst);
			bool			IsNotDecoder(IntPtr pInst);
			bool			IsPlayStarted(IntPtr pInst);
			bool			IsPlay(IntPtr pInst);
			bool			IsPause(IntPtr pInst);
			bool			Prefetch(IntPtr pInst);
			bool			Predecode(IntPtr pInst);
			bool			Play(IntPtr pInst, unsigned long nLoop, unsigned long nLoopInSample, unsigned long nStartPos);
			bool			Stop(IntPtr pInst);
			bool			Pause(IntPtr pInst);
			bool			SetVolume(IntPtr pInst, float fParam);
			bool			SetPan(IntPtr pInst, float fParam);
			bool			SetFrequencyRate(IntPtr pInst, float fParam);
			bool			Release(IntPtr pInst);

			unsigned long	GetPlayingPoint(IntPtr pInst);
			unsigned long	GetTotalSample(IntPtr pInst);
	};
}


/*  Bottom of AyameCLR.h  */
