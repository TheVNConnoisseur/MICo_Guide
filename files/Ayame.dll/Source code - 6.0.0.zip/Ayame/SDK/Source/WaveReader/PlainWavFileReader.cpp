/*
 * CPlainWavFileReader�N���X�̎������L�q���邽�߂̃t�@�C���ł��B
 * Author: AKIYAMA Kouhei
 * Created: 2002-09-27
 * Translated: Sazanta
 */

#include "PlainWavFileReader.h"


bool CPlainWavFileReader::SetRawWaveData(unsigned long size, const WAVEFORMATEX* format)
{
	if (size == 0 || format == NULL) {
		return false;
	}
	m_WaveFormat = *format;
	m_topPtr     = 0;
	m_totalSize  = size;
	m_remainSize = size;

	return true;
}

void CPlainWavFileReader::Close(void)
{
	if (m_pLoader != NULL) {
		m_pLoader->Close();
	}
}

bool CPlainWavFileReader::Read(void *dst, unsigned long size, unsigned long *read)
{
	if (!IsOpen()) {
		return false;//�J���ĂȂ�
	}

	unsigned long	readSize   = (m_remainSize < size) ? m_remainSize : size;
	unsigned long	actualRead = 0;
	actualRead = m_pLoader->Read(dst, readSize);
	m_remainSize -= actualRead;

	if (read) {
		*read = actualRead;
	}

	return true;
}

bool CPlainWavFileReader::Seek(unsigned long sample)
{
	if (!IsOpen()) {
		return false;//�J���Ă��Ȃ�
	}

	// �V�[�N����v�Z(m_topPtr����̑��Βl)
	unsigned long	moveTo = sample * m_WaveFormat.nBlockAlign;
	if (moveTo > m_totalSize) {
		return false;			//sample���傫����
	}

	// �V�[�N
	if (m_pLoader->Seek(m_topPtr + moveTo, FILE_BEGIN) == INVALID_SET_FILE_POINTER) {
		return false;			//�V�[�N�ł��Ȃ�����
	}

	//�c��T�C�Y�𒲐�
	m_remainSize = m_totalSize - moveTo;

	return true;
}

unsigned long CPlainWavFileReader::Tell(void)	const
{
	return (m_totalSize - m_remainSize) / m_WaveFormat.nBlockAlign;
}

bool CPlainWavFileReader::IsTerminated(void)	const
{
	if (IsOpen()) {
		if (m_remainSize == 0) {
			return true;
		}
	}

	return false;
}

unsigned long CPlainWavFileReader::GetTotal(void)	const
{
	return m_totalSize / m_WaveFormat.nBlockAlign;
}

unsigned long CPlainWavFileReader::GetLoopOut(void) const
{
	return GetTotal();
}

CPlainWavFileReader* CPlainWavFileReader::CreateInstance(ILoader* pLoader)
{
	if ( pLoader == NULL || pLoader->IsOpen() == false )
	{
		return NULL;
	}

	// riff�w�b�_�[([riff,riffsize,WAVE],[fmt,fmtsize])�ǂݍ���
	unsigned long	riffHead[5];				// RIFF

	pLoader->Seek(0, FILE_BEGIN);
	pLoader->Read(riffHead, sizeof(unsigned long) * 5);
	// �`�F�b�N
	if (riffHead[0] != 'FFIR' ||
		riffHead[2] != 'EVAW' ||
		riffHead[3] != ' tmf') {
		return NULL;
	}

	// fmt �`�����N�ǂݍ���
	WAVEFORMATEX	WaveFormat;
	pLoader->Read(&WaveFormat, sizeof(WAVEFORMATEX));
	if (WaveFormat.wFormatTag != WAVE_FORMAT_PCM) {
		return NULL;
	}

	// data�`�����N����
	unsigned long	dataHead[2];				// data�`�����N
	unsigned long	ptr = sizeof(unsigned long) * 5 + riffHead[4];
	for ( ;; ) {
		if (ptr >= (riffHead[1] + 8)) {
			return NULL;		//data�`�����N��������Ȃ�����
		}

		// �`�����N�w�b�_�[�ǂݍ���
		pLoader->Seek(ptr, FILE_BEGIN);
		pLoader->Read(dataHead, sizeof(unsigned long) * 2);

		// �`�F�b�N
		if (dataHead[0] == 'atad') {
			break;
		}
		ptr += 8 + dataHead[1];
	}
	ptr += 8;

	CPlainWavFileReader*	pReader = new CPlainWavFileReader();
	if (pReader == NULL) {
		return NULL;
	}

	pReader->SetLoader(pLoader);

	pReader->m_WaveFormat = WaveFormat;
	pReader->m_topPtr     = ptr;
	pReader->m_totalSize  = dataHead[1];
	pReader->m_remainSize = dataHead[1];

	return pReader;
}
