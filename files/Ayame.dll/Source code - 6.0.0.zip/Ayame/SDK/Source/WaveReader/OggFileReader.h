/*
 * COggFileReader�N���X�̃C���^�t�F�[�X���L�q���邽�߂̃t�@�C���ł��B
 * Author: AKIYAMA Kouhei
 * Created: 2002-09-27
 * Translated: Sazanta
 */

#if !defined(_OGG_FILE_READER_H_INCLUDED) && !defined(__AYAME_SIMPLE)
#define _OGG_FILE_READER_H_INCLUDED

#include <vorbis/vorbisfile.h>
#include "WaveReader.h"


/**
 * ogg�t�@�C������wave�f�[�^�����o�����߂̃N���X�ł��B
 */
class COggFileReader : public CWaveReader
{
private:
			OggVorbis_File			m_vf;
			unsigned long			m_totalSamples;
			bool					m_terminated;

	static	ov_callbacks			oggCallbacks;

private:
	static	size_t					CallbackRead  (void *ptr, size_t size, size_t nmemb, void *datasource);
	static	int						CallbackSeek  (void *datasource, ogg_int64_t offset, int whence);
	static	int						CallbackClose (void *datasource);
	static	long					CallbackTell  (void *datasource);

public:
									COggFileReader(void);
	virtual							~COggFileReader(void);

	virtual unsigned long			GetClassType(void)	const {	return 'OGGR';	}
	virtual	void					Close(void);

	virtual	bool					Read(void *dst, unsigned long size, unsigned long *read);
	virtual	bool					Seek(unsigned long sample);
	virtual	unsigned long			Tell(void) const;
	virtual	bool					IsTerminated(void) const;

	virtual	unsigned long			GetTotal(void) const;
	virtual	unsigned long			GetLoopOut(void) const;

	static COggFileReader*			CreateInstance(ILoader* pLoader);
};

#endif
