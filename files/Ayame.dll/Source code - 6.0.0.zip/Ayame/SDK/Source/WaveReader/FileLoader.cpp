/**
 * @file	FileLoader.cpp
 * @Author	Sazanta
 */
#include	"FileLoader.h"


CMemoryLoader::CMemoryLoader(void)
{
	m_pDataTopPtr = NULL;
	m_nDataNowPos = 0;
	m_nDataSize   = 0;
	m_bDelete     = false;
}


CMemoryLoader::~CMemoryLoader(void)
{
	Close();
}


bool	CMemoryLoader::Open(char* pData, size_t nSize, bool bDelete)
{
	Close();
	m_pDataTopPtr = pData;
	m_nDataNowPos = 0;
	m_nDataSize   = nSize;
	m_bDelete     = bDelete;

	return true;
}


void	CMemoryLoader::Close(void)
{
	if (m_bDelete == true && m_pDataTopPtr != NULL) {
		delete[] m_pDataTopPtr;
	}
	m_pDataTopPtr = NULL;
	m_nDataNowPos = 0;
	m_nDataSize   = 0;
}


size_t	CMemoryLoader::Seek(long nPos, unsigned long nMoveMethod)
{
	if (m_pDataTopPtr == NULL) {
		return INVALID_SET_FILE_POINTER;
	}
	if(nMoveMethod == FILE_BEGIN){
		if (nPos > (long)m_nDataSize || nPos < 0) {
			return INVALID_SET_FILE_POINTER;
		}
		m_nDataNowPos = nPos;
	}
	else if(nMoveMethod == FILE_CURRENT){
		if ((m_nDataNowPos + nPos) > m_nDataSize || (long)(m_nDataNowPos + nPos) < 0) {
			return INVALID_SET_FILE_POINTER;
		}
		m_nDataNowPos += nPos;
	}
	else if(nMoveMethod == FILE_END){
		if ((m_nDataSize + nPos) > m_nDataSize || (long)(m_nDataSize + nPos) < 0) {
			return INVALID_SET_FILE_POINTER;
		}
		m_nDataNowPos = m_nDataSize + nPos;
	}
	else{
		return INVALID_SET_FILE_POINTER;
	}
	return m_nDataNowPos;
}


size_t	CMemoryLoader::Read(void* pData, size_t nSize)
{
	if (m_pDataTopPtr == NULL) {
		return 0;
	}
	if (nSize > (m_nDataSize - m_nDataNowPos)) {
		nSize = (m_nDataSize - m_nDataNowPos);
	}
	if (pData == NULL || nSize == 0 || m_pDataTopPtr == NULL) {
		return 0;
	}
	::CopyMemory(pData, m_pDataTopPtr + m_nDataNowPos, nSize);
	m_nDataNowPos += nSize;
	return nSize;
}


//! ���[�J���t�@�C�����[�_�[
CFileLoader::CFileLoader(void)
{
	m_hFile   = INVALID_HANDLE_VALUE;
	m_nOffset = 0;
	m_nLength = 0;
	m_nNowPos = 0;
	m_bClose  = false;
}


CFileLoader::~CFileLoader(void)
{
	Close();
}


bool	CFileLoader::Open(const TCHAR* pFileName, size_t nLength, size_t nOffset)
{
	Close();
	m_hFile = ::CreateFile(pFileName, GENERIC_READ, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (m_hFile == INVALID_HANDLE_VALUE) {
		return false;
	}
	size_t	nRealLen = ::GetFileSize(m_hFile, NULL) - nOffset;
	m_nOffset = nOffset;
	m_nNowPos = nOffset;
	m_nLength = (nLength == 0 || nLength > nRealLen)? nRealLen : nLength;
	m_bClose  = true;

	return true;
}


bool	CFileLoader::Open(HANDLE hFile, size_t nLength, size_t nOffset)
{
	Close();
	if (m_hFile == INVALID_HANDLE_VALUE) {
		return false;
	}
	size_t	nRealLen = ::GetFileSize(hFile, NULL) - nOffset;
	m_hFile   = hFile;
	m_nOffset = nOffset;
	m_nNowPos = nOffset;
	m_nLength = (nLength == 0 || nLength > nRealLen)? nRealLen : nLength;
	m_bClose  = false;

	return true;
}


void	CFileLoader::Close(void)
{
	if (m_hFile != INVALID_HANDLE_VALUE && m_bClose == true) {
		::CloseHandle(m_hFile);
		m_hFile = INVALID_HANDLE_VALUE;
	}
	m_nOffset = 0;
	m_nLength = 0;
}


size_t	CFileLoader::Seek(long nPos, unsigned long nMoveMethod)
{
	if (m_hFile == INVALID_HANDLE_VALUE) {
		return INVALID_SET_FILE_POINTER;
	}
	if (nMoveMethod == FILE_BEGIN) {
		m_nNowPos = nPos + m_nOffset;
	} else if (nMoveMethod == FILE_CURRENT) {
		m_nNowPos += nPos;
	} else if (nMoveMethod == FILE_END) {
		m_nNowPos = m_nLength + nPos + m_nOffset;
	}
	if (m_nNowPos > (m_nLength + m_nOffset)) {
		return INVALID_SET_FILE_POINTER;
	}

	return m_nNowPos - m_nOffset;
}


size_t	CFileLoader::Tell(void)	const
{
	if (m_hFile == INVALID_HANDLE_VALUE) {
		return 0;
	}

	return m_nNowPos - m_nOffset;
}


size_t	CFileLoader::Read(void* pData, size_t nSize)
{
	if (m_hFile == INVALID_HANDLE_VALUE) {
		return 0;
	}
	if ((Tell() + nSize) > m_nLength) {
		nSize = m_nLength - Tell();
		if (nSize == 0) {
			return 0;
		}
	}

	if (::SetFilePointer(m_hFile, m_nNowPos, NULL, FILE_BEGIN) == INVALID_SET_FILE_POINTER) {
		return 0;
	}
	unsigned long	nReadSize;
	::ReadFile(m_hFile, pData, nSize, &nReadSize, NULL);
	m_nNowPos += nReadSize;

	return nReadSize;
}


//! �C���^�[�l�b�g�t�@�C�����[�_�[(HTTP�A�N�Z�X)
CHttpLoader::CHttpLoader(void)
{
	m_hInternet = NULL;
	m_hFile     = NULL;
	m_nOffset   = 0;
	m_nLength   = 0;
	m_nNowPos   = 0;

	m_hInetLib               = NULL;
	InternetOpen_f           = NULL;
	InternetOpenUrl_f        = NULL;
	HttpQueryInfo_f          = NULL;
	InternetCloseHandle_f    = NULL;
	InternetSetFilePointer_f = NULL;
	InternetReadFile_f       = NULL;
}


CHttpLoader::~CHttpLoader(void)
{
	Close();
}


bool	CHttpLoader::OpenDLL(void)
{
#ifdef _UNICODE
	if ((m_hInetLib = LoadLibrary(L"wininet.dll")) == NULL) {
		return false;
	}
	InternetOpen_f           = (_InternetOpen)GetProcAddress(m_hInetLib, "InternetOpenW");
	InternetOpenUrl_f        = (_InternetOpenUrl)GetProcAddress(m_hInetLib, "InternetOpenUrlW");
	HttpQueryInfo_f          = (_HttpQueryInfo)GetProcAddress(m_hInetLib, "HttpQueryInfoW");
#else
	if ((m_hInetLib = LoadLibrary("wininet.dll")) == NULL) {
		return false;
	}
	InternetOpen_f           = (_InternetOpen)GetProcAddress(m_hInetLib, "InternetOpenA");
	InternetOpenUrl_f        = (_InternetOpenUrl)GetProcAddress(m_hInetLib, "InternetOpenUrlA");
	HttpQueryInfo_f          = (_HttpQueryInfo)GetProcAddress(m_hInetLib, "HttpQueryInfoA");
#endif
	InternetCloseHandle_f    = (_InternetCloseHandle)GetProcAddress(m_hInetLib, "InternetCloseHandle");
	InternetSetFilePointer_f = (_InternetSetFilePointer)GetProcAddress(m_hInetLib, "InternetSetFilePointer");
	InternetReadFile_f       = (_InternetReadFile)GetProcAddress(m_hInetLib, "InternetReadFile");
	if (InternetOpen_f == NULL ||
		InternetOpenUrl_f == NULL ||
		HttpQueryInfo_f == NULL ||
		InternetCloseHandle_f == NULL ||
		InternetSetFilePointer_f == NULL ||
		InternetReadFile_f == NULL) {
		CloseDLL();
		return false;
	}

	return true;
}


void	CHttpLoader::CloseDLL(void)
{
	if (m_hInetLib != NULL) {
		FreeLibrary(m_hInetLib);
		m_hInetLib = NULL;
	}
	InternetOpen_f           = NULL;
	InternetOpenUrl_f        = NULL;
	HttpQueryInfo_f          = NULL;
	InternetCloseHandle_f    = NULL;
	InternetSetFilePointer_f = NULL;
	InternetReadFile_f       = NULL;
}


bool	CHttpLoader::Open(const TCHAR* pUrl, size_t nLength, size_t nOffset)
{
	Close();

	if (OpenDLL() == false) {
		return false;
	}
#ifdef _UNICODE
	m_hInternet = InternetOpen_f(L"Ayame Internet Loader", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
#else
	m_hInternet = InternetOpen_f("Ayame Internet Loader", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
#endif
	if (m_hInternet == NULL) {
		return false;
	}
	m_hFile = InternetOpenUrl_f(m_hInternet, pUrl, NULL, 0, INTERNET_FLAG_RELOAD, 0);
	if (m_hFile == NULL) {
		return false;
	}
	unsigned long	nRealLen;
	unsigned long	dwSize = sizeof(nRealLen);
	HttpQueryInfo_f(m_hFile, HTTP_QUERY_CONTENT_LENGTH | HTTP_QUERY_FLAG_NUMBER, &nRealLen, &dwSize, 0);
	nRealLen -= nOffset;
	m_nOffset = nOffset;
	m_nNowPos = nOffset;
	m_nLength = (nLength == 0 || nLength > nRealLen)? nRealLen : nLength;
	return true;
}


void	CHttpLoader::Close(void)
{
	if (m_hFile != NULL) {
		InternetCloseHandle_f(m_hFile);
		m_hFile = NULL;
	}
	if (m_hInternet != NULL) {
		InternetCloseHandle_f(m_hInternet);
		m_hInternet = NULL;
	}
	CloseDLL();
	m_nOffset = 0;
	m_nLength = 0;
}


size_t	CHttpLoader::Seek(long nPos, unsigned long nMoveMethod)
{
	if (m_hFile == NULL) {
		return INVALID_SET_FILE_POINTER;
	}
	if (nMoveMethod == FILE_BEGIN) {
		m_nNowPos = nPos + m_nOffset;
	} else if (nMoveMethod == FILE_CURRENT) {
		m_nNowPos += nPos;
	} else if (nMoveMethod == FILE_END) {
		m_nNowPos = m_nLength + nPos + m_nOffset;
	}
	if (m_nNowPos > (m_nLength + m_nOffset)) {
		return INVALID_SET_FILE_POINTER;
	}
	return m_nNowPos - m_nOffset;
}


size_t	CHttpLoader::Tell(void)	const
{
	if (m_hFile == NULL) {
		return 0;
	}
	return m_nNowPos - m_nOffset;
}


size_t	CHttpLoader::Read(void* pData, size_t nSize)
{
	if (m_hFile == NULL) {
		return 0;
	}
	if ((Tell() + nSize) > m_nLength) {
		nSize = m_nLength - Tell();
		if (nSize == 0) {
			return 0;
		}
	}

	if (InternetSetFilePointer_f(m_hFile, m_nNowPos, NULL, FILE_BEGIN, 0) == INVALID_SET_FILE_POINTER) {
		return 0;
	}
	unsigned long	nReadSize;
	InternetReadFile_f(m_hFile, pData, nSize, &nReadSize);
	m_nNowPos += nReadSize;

	return nReadSize;
}


/*  Bottom of FileLoader.cpp  */
