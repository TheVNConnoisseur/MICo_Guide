/**
 * @file	FileLoader.h
 * @Author	Sazanta
 */
#ifndef _FILELOADER_H_INCLUDED
#define _FILELOADER_H_INCLUDED

#include	<windows.h>
#include	<wininet.h>


//! ���[�_�[�C���^�[�t�F�C�X
class ILoader
{
public:
	virtual							~ILoader(void){}

	virtual	void					Close(void) = 0;

	virtual	unsigned long			GetClassType(void)	const = 0;

	virtual	bool					IsOpen(void)	const = 0;
	virtual	size_t					GetFileSize(void)	const = 0;
	virtual	size_t					Seek(long nPos, unsigned long nMoveMethod) = 0;
	virtual	size_t					Tell(void)	const = 0;
	virtual	size_t					Read(void* pData, size_t nSize) = 0;
};


//! ���������[�_�[
class CMemoryLoader : public ILoader
{
private:
			char*					m_pDataTopPtr;
			size_t					m_nDataNowPos;
			size_t					m_nDataSize;
			bool					m_bDelete;

public:
									CMemoryLoader(void);
	virtual							~CMemoryLoader(void);

			unsigned long			GetClassType(void)	const	{
										return 'MEML';
									}

			bool					IsOpen(void)	const	{
										return (m_pDataTopPtr != NULL);
									}
			bool					Open(char* pData, size_t nSize, bool bDelete = false);
			void					Close(void);

			size_t					GetFileSize(void)	const	{
										return m_nDataSize;
									}
			size_t					Seek(long nPos, unsigned long nMoveMethod);
			size_t					Tell(void)	const	{
										return m_nDataNowPos;
									}
			size_t					Read(void* pData, size_t nSize);
};


//! ���[�J���t�@�C�����[�_�[
class CFileLoader : public ILoader
{
private:
			HANDLE					m_hFile;
			size_t					m_nOffset;
			size_t					m_nLength;
			size_t					m_nNowPos;
			bool					m_bClose;

public:
									CFileLoader(void);
	virtual							~CFileLoader(void);

			unsigned long			GetClassType(void)	const	{
										return 'LFLD';
									}

			bool					IsOpen(void)	const	{
										return (m_hFile != INVALID_HANDLE_VALUE);
									}
			bool					Open(const TCHAR* pFileName, size_t nLength = 0, size_t nOffset = 0);
			bool					Open(HANDLE hFile, size_t nLength = 0, size_t nOffset = 0);
			void					Close(void);

			size_t					GetFileSize(void)	const	{
										return m_nLength;
									}
			size_t					Seek(long nPos, unsigned long nMoveMethod);
			size_t					Tell(void)	const;
			size_t					Read(void* pData, size_t nSize);
};


#ifdef __cplusplus
extern "C" {  // only need to export C interface if
              // used by C++ source code
#endif
#ifdef _UNICODE
typedef HINTERNET		(CALLBACK* _InternetOpen)(LPCWSTR, DWORD, LPCWSTR, LPCWSTR, DWORD);
typedef	HINTERNET		(CALLBACK* _InternetOpenUrl)(HINTERNET, LPCWSTR, LPCWSTR, DWORD, DWORD, DWORD);
#else
typedef HINTERNET		(CALLBACK* _InternetOpen)(LPCSTR, DWORD, LPCSTR, LPCSTR, DWORD);
typedef	HINTERNET		(CALLBACK* _InternetOpenUrl)(HINTERNET, LPCSTR, LPCSTR, DWORD, DWORD, DWORD);
#endif
typedef	BOOL			(CALLBACK* _HttpQueryInfo)(HINTERNET, DWORD, LPVOID, LPDWORD, LPDWORD);
typedef	BOOL			(CALLBACK* _InternetCloseHandle)(HINTERNET);
typedef	DWORD			(CALLBACK* _InternetSetFilePointer)(HINTERNET, LONG, PVOID, DWORD, DWORD_PTR);
typedef	BOOL			(CALLBACK* _InternetReadFile)(HINTERNET, LPVOID, DWORD, LPDWORD);
#ifdef __cplusplus
}
#endif

//! �C���^�[�l�b�g�t�@�C�����[�_�[(HTTP�A�N�Z�X)
class CHttpLoader : public ILoader
{
private:
			HINTERNET				m_hInternet;
			HINTERNET				m_hFile;
			size_t					m_nOffset;
			size_t					m_nLength;
			size_t					m_nNowPos;

			HINSTANCE				m_hInetLib;
			_InternetOpen			InternetOpen_f;
			_InternetOpenUrl		InternetOpenUrl_f;
			_HttpQueryInfo			HttpQueryInfo_f;
			_InternetCloseHandle	InternetCloseHandle_f;
			_InternetSetFilePointer	InternetSetFilePointer_f;
			_InternetReadFile		InternetReadFile_f;

public:
									CHttpLoader(void);
	virtual							~CHttpLoader(void);

			bool					OpenDLL(void);
			void					CloseDLL(void);

			unsigned long			GetClassType(void)	const	{
										return 'NETL';
									}

			bool					IsOpen(void)	const	{
										return (m_hFile != INVALID_HANDLE_VALUE && m_hInetLib != NULL);
									}
			bool					Open(const TCHAR* pUrl, size_t nLength = 0, size_t nOffset = 0);
			void					Close(void);

			size_t					GetFileSize(void)	const	{
										return m_nLength;
									}
			size_t					Seek(long nPos, unsigned long nMoveMethod);
			size_t					Tell(void)	const;
			size_t					Read(void* pData, size_t nSize);
};


#endif
/*  Bottom of FileLoader.h  */
