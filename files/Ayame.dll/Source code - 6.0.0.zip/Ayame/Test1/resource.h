//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.rc
//
#define IDC_LOAD                        1001
#define IDC_PLAY                        1002
#define IDC_STOP                        1003
#define IDC_EDIT1                       1004
#define IDC_FILENAME                    1004
#define IDC_SLIDER1                     1005
#define IDC_SLIDER                      1005
#define IDC_STOP2                       1006
#define IDC_PAUSE                       1006
#define IDC_CHECK1                      1007
#define IDC_CHECK                       1007
#define IDC_LOOPCHECK                   1007
#define IDC_LOOP                        1007
#define IDC_INFINITLOOP                 1007
#define IDC_SLIDER2                     1008
#define IDC_SLIDER3                     1009
#define IDC_BUTTON1                     1010
#define IDC_SELECTFILE                  1010
#define IDC_PREFETCH                    1011
#define IDC_FILENAME2                   1012
#define IDC_SELECTFILE2                 1013
#define IDC_PREDECODE                   1014
#define IDC_STREAM                      1015
#define IDC_LOOPNUM                     1016
#define IDC_EDIT3                       1017
#define IDC_STARTPOS                    1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
