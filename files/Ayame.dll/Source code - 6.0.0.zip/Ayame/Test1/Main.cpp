

//==========================================================================
// INCLUDE
//==========================================================================
#include <windows.h>
#include <stdio.h>
#include <shlobj.h>
#include <commctrl.h>
#include <winnls32.h>

#include "../Master/Ayame.h"
#include "../Master/AyameManager.h"
#include "resource.h"


//==========================================================================
// VARIABLE
//==========================================================================
static CAyameManager				cAyameMgr;
static CAyame*						pAyame			= NULL;
static float						fVolume			= 100.0f;
static DSCAPS						stCaps;
static DWORD						nVersion;


//==========================================================================
// PROTOTYPE
//==========================================================================
static LRESULT CALLBACK DlgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
static bool FileOpenDialog( char *pPath, HWND hWnd );


//==========================================================================
//
//		WinMain
//
//==========================================================================
int WINAPI WinMain( HINSTANCE hInst, HINSTANCE hPreInst, LPSTR lpszCmdLine, int nCmdShow )
{
	//--------------------------------------------------
	// �_�C�A���O�{�b�N�X�I�[�v��
	//--------------------------------------------------
	::CoInitialize( NULL );

	::DialogBox( hInst, "IDD_DIALOG_MAIN", NULL, (DLGPROC)DlgProc );

	::CoUninitialize();

	return 0L;
}

BOOL CALLBACK DSEnumProc(LPGUID lpGUID, LPCTSTR lpszDesc, LPCTSTR lpszDrvName, LPVOID lpContext)
{
	printf(lpszDesc);

	return TRUE;
}


//==========================================================================
//
//		���b�Z�[�W�֐�
//
//==========================================================================
LRESULT CALLBACK DlgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	char FileName[256] = "";

	switch ( msg )
	{
	//------------------------------------------------------ �_�C�A���O��������
	case WM_INITDIALOG:
		// �h���C�o�̏�����
		if ( !cAyameMgr.LoadDLL( "Ayame.dll" ) )
		{
			::MessageBox( hWnd, "AyameDLL�̏������Ɏ��s", "ERROR", MB_ICONSTOP );
			// �I�����b�Z�[�W���s
			::PostMessage( hWnd, WM_CLOSE, 0, 0 );
		}

		cAyameMgr.SoundDeviceEnumerate(DSEnumProc, NULL);

		if ( !cAyameMgr.Initialize( hWnd, NULL, NULL ) )
		{
			::MessageBox( hWnd, "Ayame�̏������Ɏ��s", "ERROR", MB_ICONSTOP );
			// �I�����b�Z�[�W���s
			::PostMessage( hWnd, WM_CLOSE, 0, 0 );
		}
		nVersion = cAyameMgr.GetVersion();
		cAyameMgr.GetDirectSoundCaps(&stCaps);
		// �t�@�C�������󔒂ɂ��Ƃ�
		::SetDlgItemText( hWnd, IDC_FILENAME, "--- �t�@�C���� ---" );
		// �{�����[���X���C�h�o�[
		::SendDlgItemMessage( hWnd, IDC_SLIDER, TBM_SETRANGE, TRUE, MAKELPARAM(0,100) );
		// �Đ��X���C�h�o�[
		::SendDlgItemMessage( hWnd, IDC_SLIDER2, TBM_SETRANGE, TRUE, MAKELPARAM(0,10000) );
		// �s�b�`�X���C�h�o�[
		::SendDlgItemMessage( hWnd, IDC_SLIDER3, TBM_SETRANGE, TRUE, MAKELPARAM(0,100) );
		::SendDlgItemMessage( hWnd, IDC_SLIDER3, TBM_SETPOS, TRUE, (long)50 );
		::SendDlgItemMessage( hWnd, IDC_STREAM, BM_SETCHECK, TRUE, 0);
		break;
	//------------------------------------------------------ �R�}���h������
	case WM_COMMAND:
		switch ( LOWORD( wParam ) )
		{
		// ---------------------------------------- �t�@�C���I��
		case IDC_SELECTFILE:
			if ( FileOpenDialog( FileName, hWnd ) )
			{
				::SetDlgItemText( hWnd, IDC_FILENAME, FileName );
			}
			break;
		case IDC_SELECTFILE2:
			if ( FileOpenDialog( FileName, hWnd ) )
			{
				::SetDlgItemText( hWnd, IDC_FILENAME2, FileName );
			}
			break;
		// ---------------------------------------- �ǂݍ���
		case IDC_LOAD:
			{
				unsigned long	nFlag = AYAME_LOADFLAG_GLOBAL | (IsDlgButtonChecked(hWnd, IDC_STREAM)? AYAME_LOADFLAG_STREAM : AYAME_LOADFLAG_STATIC);
				::GetDlgItemText( hWnd, IDC_FILENAME, FileName , 256);
				if ( pAyame != NULL ) pAyame->Release();
				pAyame = (strnicmp(FileName, "http:", 5) != 0)? cAyameMgr.CreateInstanceFromFile( FileName, 0, 0, nFlag ) : cAyameMgr.CreateInstanceFromUrl( FileName, 0, 0, nFlag );
				if ( pAyame == NULL )
				{
					char Error[256] = "";
					cAyameMgr.GetLastError( Error, 256 );
					::MessageBox( hWnd, Error, "ERROR", MB_ICONSTOP );
				}

				if ( IsDlgButtonChecked(hWnd, IDC_STREAM) == TRUE )
				{
					::GetDlgItemText( hWnd, IDC_FILENAME2, FileName , 256);
					CAyame	*pNextAyame = (strnicmp(FileName, "http:", 5) != 0)? cAyameMgr.CreateInstanceFromFile( FileName, 0, 0 ) : cAyameMgr.CreateInstanceFromUrl( FileName, 0, 0 );
					if ( pNextAyame != NULL )
					{
						pAyame->Combine(pNextAyame);
					}
				}

				fVolume = 100.0f;

				::SendDlgItemMessage( hWnd, IDC_SLIDER, TBM_SETPOS, TRUE, (long)fVolume );
				::SendDlgItemMessage( hWnd, IDC_SLIDER3, TBM_SETPOS, TRUE, (long)50 );

				// �{�����[��
				pAyame->SetVolume( fVolume );
				if ( IsDlgButtonChecked( hWnd, IDC_PREDECODE ) != 0 )
				{
					pAyame->Predecode();
				}
				else if ( IsDlgButtonChecked( hWnd, IDC_PREFETCH ) != 0 )
				{
					pAyame->Prefetch();
				}
			}
			break;
		// ---------------------------------------- �Đ�
		case IDC_PLAY:
			if ( pAyame != NULL )
			{
				if ( pAyame->IsPlay() == false )
				{
					::GetDlgItemText( hWnd, IDC_LOOPNUM, FileName , 256);
					unsigned long	nLoop = ( IsDlgButtonChecked( hWnd, IDC_LOOP ) != 0 )? AYAME_LOOP_INFINITY : atoi(FileName);
					::GetDlgItemText( hWnd, IDC_STARTPOS, FileName , 256);
					unsigned long	nStartPos = atoi(FileName);
					if ( !pAyame->Play( nLoop, 0, nStartPos ) )
					{
						char Error[256] = "";
						cAyameMgr.GetLastError( Error, 256 );
						::MessageBox( hWnd, Error, "ERROR", MB_ICONSTOP );
					}
					else
					{
						SetTimer( hWnd, 0, 100, NULL );
					}
					::SendDlgItemMessage( hWnd, IDC_PLAY, WM_SETTEXT, TRUE, (LPARAM)"�ꎞ��~");
				}
				else
				{
					pAyame->Pause();
				}
			}
			break;
		// ---------------------------------------- ��~
		case IDC_STOP:
			if ( pAyame != NULL )
			{
				if ( !pAyame->Stop() )
				{
					char Error[256] = "";
					cAyameMgr.GetLastError( Error, 256 );
					::MessageBox( hWnd, Error, "ERROR", MB_ICONSTOP );
				}
				else
				{
					KillTimer(hWnd, 0);
				}
				::SendDlgItemMessage( hWnd, IDC_PLAY, WM_SETTEXT, TRUE, (LPARAM)"�Đ�");
			}
			break;

		case IDC_STREAM:
			BOOL	bFlag = IsDlgButtonChecked(hWnd, IDC_STREAM);
			::SendDlgItemMessage( hWnd, IDC_LOOPNUM, WM_ENABLE, bFlag, 0);
			::SendDlgItemMessage( hWnd, IDC_FILENAME2, WM_ENABLE, bFlag, 0);
			EnableWindow(GetDlgItem(hWnd, IDC_SELECTFILE2), bFlag);
			break;
		}
		break;
	// ---------------------------------------- �X���C�_�[
	case WM_HSCROLL:
		if ( pAyame != NULL )
		{
			if ( GetDlgItem( hWnd, IDC_SLIDER ) == (HWND)lParam )
			{
				fVolume = (float)::SendDlgItemMessage( hWnd, IDC_SLIDER, TBM_GETPOS, 0L, 0L );
				pAyame->SetVolume( fVolume );
			}
			if ( GetDlgItem( hWnd, IDC_SLIDER3 ) == (HWND)lParam )
			{
				float	fPitch = (float)::SendDlgItemMessage( hWnd, IDC_SLIDER3, TBM_GETPOS, 0L, 0L );
				pAyame->SetFrequencyRate( fPitch / 50.0f );
			}
		}
		break;
	case WM_TIMER:
		if ( pAyame != NULL )
		{
			unsigned long nTotal = pAyame->GetTotalSample();
			unsigned long nPos = pAyame->GetPlayingPoint();
			float	fPer = (float)nPos / nTotal;
			::SendDlgItemMessage( hWnd, IDC_SLIDER2, TBM_SETPOS, TRUE, (long)(fPer * 10000) );
			if ( pAyame->IsPlay() == false )
			{
				::SendDlgItemMessage( hWnd, IDC_PLAY, WM_SETTEXT, TRUE, (LPARAM)"�Đ�");
			}
		}
		break;
 	//------------------------------------------------------ �_�C�A���O�I����
	case WM_CLOSE:
		if ( pAyame != NULL )
		{
//			pAyame->Release();
		}
		KillTimer(hWnd, 0);
		// �h���C�o�̏I��
		cAyameMgr.Release();
		// �_�C�A���O�̏I��
		::EndDialog( hWnd, IDCANCEL );
		return TRUE;
	}

	return FALSE;
}

//==========================================================================
//
//		�t�@�C���I�[�v���t�@�C�A���O
//
//==========================================================================
bool FileOpenDialog( char *pPath, HWND hWnd )
{
	char Temp[512] = "";

	OPENFILENAME ofn;
	ZeroMemory( &ofn, sizeof(OPENFILENAME) );
	
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = hWnd;
	ofn.lpstrTitle = "Ayame�t�@�C���ǂݍ���";
	ofn.lpstrFilter = "OGG/WAVE/MP3�t�@�C�� (*.ogg;*.wav;*.mp3)\0*.ogg;*.wav;*.mp3\0�S�Ẵt�@�C�� (*.*)\0*.*\0\0";
	ofn.lpstrDefExt = "";
	ofn.nFilterIndex = 1;
	ofn.lpstrFile = Temp;
	ofn.nMaxFile = sizeof(Temp);
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;

	if ( GetOpenFileName( &ofn ) != 0 )
	{
		if ( Temp[0] != '\0' )
		{
			strcpy( pPath, Temp );
			return TRUE;
		}
	}

	return FALSE;
}

